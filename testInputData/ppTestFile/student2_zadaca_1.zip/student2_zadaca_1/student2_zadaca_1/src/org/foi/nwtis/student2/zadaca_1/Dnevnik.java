/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student2.zadaca_1;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author student2
 */
public class Dnevnik {

    private String nazivDatoteke;

    private Dnevnik() {
    }

    /**
     *
     * @return DnevnikHolder.INSTANCE
     */
    public static Dnevnik getInstance() {
        return DnevnikHolder.INSTANCE;
    }

    private static class DnevnikHolder {

        private static final Dnevnik INSTANCE = new Dnevnik();
    }

    /**
     *
     * @return nazivDatoteke Vraca naziv datoteke dnevnika
     */
    public String getNazivDatoteke() {
        return nazivDatoteke;
    }

    /**
     * Postavlja ime datoteke dnevnika
     * @param nazivDatoteke Ime dnevnika
     */
    public void setNazivDatoteke(String nazivDatoteke) {
        this.nazivDatoteke = nazivDatoteke;
    }

    /**
     * Ispisuje poruku u datoteku dnevnik
     * @param poruka Poruka koja se upisuje u dnevnik
     */
    public synchronized void upisi(String poruka) {

        //TODO upisati u datoteku
        DateFormat dateFormat = new SimpleDateFormat("yyyy_MM_dd");
        Date date = new Date();
        String putanja = nazivDatoteke + "." + dateFormat.format(date) + ".log";

        File datoteka = new File(putanja);
        
        if (datoteka.exists()) {
            FileWriter writer;
            try {
                writer = new FileWriter(putanja, true);
                writer.write(poruka + "\r\n");
                writer.close();
            } catch (IOException ex) {
                Logger.getLogger(Dnevnik.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
    }
}
