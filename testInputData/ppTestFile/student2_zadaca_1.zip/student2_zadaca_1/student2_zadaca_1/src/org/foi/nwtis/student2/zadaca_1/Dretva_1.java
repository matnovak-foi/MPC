/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student2.zadaca_1;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author student2
 * Klasa Dretva_1 - pokrece do 9 dretvi, ovisno o konfiguracijskoj datoteci, koje provjeravaju
 *                  da li se dogodila promjena na URL-u koji pojedina dretva prati, a zapisan
 *                  je u konfiguracijskoj datoteci.
 *                  
 */
public class Dretva_1 extends Thread {

    private int broj;
    private int interval;
    private String izvor, putanja;
    private Dnevnik dnevnik;
    private DateFormat dateFormat = new SimpleDateFormat("yyyy.MM.dd HH.mm.ss");
    private DateFormat dateFormat2 = new SimpleDateFormat("dd.MM.yyyy. HH:mm:ss");
    int ucitano = 0;

    /**
     *
     * @param broj Broj dretve koja je stvorena
     * @param interval Vrijeme nakon kojeg dretva ponavlja svoj posao
     * @param izvor URL sa kojega cita (ocitava ga iz konfiguracijske datoteke)
     * @param dnevnik Objekt klase Dnevnik
     */
    public Dretva_1(int broj, int interval, String izvor, Dnevnik dnevnik) {
        super("nwtis => dretva 1." + broj);
        this.broj = broj;
        this.interval = interval;
        this.izvor = izvor;
        this.dnevnik = dnevnik;
        System.out.println("Dretva " + broj + " inicijalizirana.");
    }

    /*
     * Metoda pokrece dretvu koja provjerava da li je izvor file ili url.
     * Zatim nakon intervala zadanog u konfiguracijskoj datoteci preispituje da
     * li doslo do promjene u velicini sadrzaja izvora.
     * Ako je doslo do promjene zapisuje u datoteku dnevnika vrijeme i status
     * promjene.
     * Kada se dretva ugasi u datoteku dnevnika zapisuje vrijeme zavrsetka.
     */
    @Override
    public void run() {

        System.out.println(this.getName() + " pokrenuta");
        int iteracija = 0;
        String textURL = "";
        while (true) {
            long pocetak = System.currentTimeMillis();
            try {
                System.out.println(this.getName() + " izvodi iteraciju " + iteracija++);
                Date date = new Date();

                if (izvor.substring(0, 4).equals("file")) {
                    try {
                        putanja = izvor.substring(6, izvor.length());
                        BufferedReader bf = new BufferedReader(new FileReader(putanja));
                        String text, stariText = "";
                        while ((text = bf.readLine()) != null) {
                            stariText = stariText + text;
                        }
                        if (stariText.length() != ucitano) {
                            //System.out.println(stariText + "  " + stariText.length() + "   " + ucitano);
                            ucitano = stariText.length();
                            dnevnik.upisi(this.getName() + "\t" + dateFormat.format(date) + "\t promijenjeno");
                        }

                    } catch (FileNotFoundException ex) {
                        System.out.println(this.getName() + " Nepostojeća datoteka!");
                    } catch (IOException ex) {
                    }
                } else {
                    URL url;
                    try {
                        url = new URL(izvor);
                        BufferedReader in;
                        in = new BufferedReader(new InputStreamReader(url.openStream()));
                        String inputLine, text = "";
                        while ((inputLine = in.readLine()) != null) {
                            text = text + inputLine;
                        }
                        if (text.length() != textURL.length()) {
                            dnevnik.upisi(this.getName() + "\t" + dateFormat.format(date) + "\t promijenjeno");
                            textURL = text;
                        }
                        in.close();

                    } catch (MalformedURLException ex1) {
                        System.out.println(this.getName() + " Ne postojeći URL!");
                    } catch (IOException ex1) {
                    }
                }

                /*
                 * Racunanje intervala koji je potreban da se dretva ponovo aktivira
                 */
                long kraj = System.currentTimeMillis();
                if ((interval * 1000 - (kraj - pocetak) > 0)) {
                    sleep((interval * 1000 - (kraj - pocetak)));
                } else {
                    sleep(0);
                }
            } catch (InterruptedException ex) {
                System.out.println(this.getName() + " prekinuta");
                Date datum = new Date();
                /*
                 * Upisivanje vremena prekida u dnevnik
                 */
                dnevnik.upisi(this.getName() + " prekinuta u " + dateFormat2.format(datum));
                break;
            }
        }

    }
}
