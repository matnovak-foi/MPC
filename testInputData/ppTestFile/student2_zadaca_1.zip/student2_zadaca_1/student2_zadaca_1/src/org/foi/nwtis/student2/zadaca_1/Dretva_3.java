/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student2.zadaca_1;

import java.io.File;
import java.util.Timer;
import java.util.TimerTask;

/**
 *
 * @author student2
 *
 * Klasa nasljeduje klasu TimerTask da bi mogla u intervalima odredenim
 * konfiguracijskom datotekom provjeriti postoji li odredena datoteka (odredena
 * u konfiguracijskoj datoteci). Ako postoji, zadaca je ugasiti sve dretve.
 */
public class Dretva_3 extends TimerTask {

    private String datotekaKraj;
    private Dretva_1[] dretve_1;
    private Dretva_2 dretve_2;
    private Timer timer;

    /**
     *
     * @param datotekaKraj Ako postoji datoteka dretva_3 treba ugasiti dretve
     * @param dretve_1 Polje objekata klase Dretva_1
     * @param dretve_2 Objekt klase Dretva_2
     * @param timer Objekt klase Timer
     */
    public Dretva_3(String datotekaKraj, Dretva_1[] dretve_1, Dretva_2 dretve_2, Timer timer) {
        this.dretve_1 = dretve_1;
        this.dretve_2 = dretve_2;
        this.datotekaKraj = datotekaKraj;
        this.timer = timer;
    }

    /*
     * Metoda provjerava da li postoji datoteka cije ime je ocitano iz
     * konfiguracijske datoteke.
     * Ako postoji ugasi dretve
     */
    @Override
    public void run() {
        System.out.println("nwtis => dretva 3 pokrenuta");

        File datoteka = new File(datotekaKraj);
        if (!datoteka.exists()) {
            System.out.println("nwtis => dretva 3 => Nema datoteke, nista ne zaustavljam!");
        } else {
            System.out.println("nwtis => dretva 3 => Pronadena datoteka, zaustavljam dretve!");
            for (Dretva_1 d : dretve_1) {
                System.out.println("nwtis => dretva 3 => Zaustavljam dretvu: " + d.getName());
                d.interrupt();
            }
            System.out.println("nwtis => dretva 3 => Zaustavljam dretvu: " + dretve_2.getName());
            dretve_2.interrupt();
            timer.cancel();
        }
    }
}
