/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student2.zadaca_1;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author student2
 */
public class Dretva_2 extends Thread {

    private String vrijemePocetka, dnevnikDatoteka;
    private Dnevnik dnevnik;
    private DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
    private DateFormat dateFormat2 = new SimpleDateFormat("dd.MM.yyyy. HH:mm:ss");
    private DateFormat dateFormat3 = new SimpleDateFormat("yyyy_MM_dd");
    private Calendar trenutnoVrijeme, zadanoVrijeme, vrijeme;

    /**
     * Konstruktor klase Dretva_2
     * @param vrijemePocetka Vrijeme kada Dretva_2 treba poceti s radom
     * @param dnevnik Objekat klase Dnevnik
     * @param dnevnikDatoteka Ime datoteke dnevnik iscitano iz konfiguracijske datoteke
     */
    public Dretva_2(String vrijemePocetka, Dnevnik dnevnik, String dnevnikDatoteka) {
        super("nwtis => dretva 2 ");
        this.vrijemePocetka = vrijemePocetka;
        this.dnevnik = dnevnik;
        this.dnevnikDatoteka = dnevnikDatoteka;
    }

    /*
     * Metoda pokrece dretvu koja racuna koliko treba spavati da bi krenla sa
     * radom.
     * Provjerava da li postoji datoteka sa trenutnim datumom, ako ne postoji kreira ju.
     * Kada se dretva ugasi u datoteku dnevnika zapisuje vrijeme zavrsetka.
     *
     */
    @Override
    public void run() {
        System.out.println(this.getName() + " pokrenuta");
        int iteracija = 0;
        int interval = 24 * 60 * 60 * 1000; //1 dan

        try {
            Date date = new Date();
            date = (Date) dateFormat.parse(vrijemePocetka);
            zadanoVrijeme = Calendar.getInstance();
            zadanoVrijeme.setTime(date);

        } catch (ParseException ex) {
            Logger.getLogger(Dretva_2.class.getName()).log(Level.SEVERE, null, ex);
        }

        while (true) {
            trenutnoVrijeme = new GregorianCalendar();
            vrijeme = new GregorianCalendar();
            vrijeme.set(Calendar.HOUR_OF_DAY, zadanoVrijeme.get(Calendar.HOUR_OF_DAY));
            vrijeme.set(Calendar.MINUTE, zadanoVrijeme.get(Calendar.MINUTE));
            vrijeme.set(Calendar.SECOND, zadanoVrijeme.get(Calendar.SECOND));

            try {
                /*
                 * Racuanje vremena potrebnog za spavanje dretve.
                 */
                if (trenutnoVrijeme.getTimeInMillis() > vrijeme.getTimeInMillis()) {
                    sleep(interval - (trenutnoVrijeme.getTimeInMillis() - vrijeme.getTimeInMillis()));
                } else {
                    sleep(vrijeme.getTimeInMillis() - trenutnoVrijeme.getTimeInMillis());
                }
                System.out.println(this.getName() + " izvodi iteraciju " + iteracija++);

                /*
                 * Ispituje postoji li datoteka dnevnika sa trenutnim datumom.
                 * Ako ne postoji kreira jednu.
                 */
                Date date = new Date();
                String putanja = dnevnikDatoteka + "." + dateFormat3.format(date) + ".log";
                File datoteka = new File(putanja);
                if (!datoteka.exists()) {
                    datoteka.createNewFile();
                    System.out.println("Stvorena datoteka dnevnika, dretva 2");
                }
                System.out.println("Dretva 2 odspavala");
            } catch (InterruptedException ex) {
                /*
                 * Ako je dretva prekinuta zapisuje u dnevnik vrijeme prekida.
                 */
                System.out.println(this.getName() + " prekinuta");
                Date datum = new Date();
                dnevnik.upisi(this.getName() + " prekinuta u " + dateFormat2.format(datum));
                break;
            } catch (IOException ex) {
                Logger.getLogger(Dretva_2.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
