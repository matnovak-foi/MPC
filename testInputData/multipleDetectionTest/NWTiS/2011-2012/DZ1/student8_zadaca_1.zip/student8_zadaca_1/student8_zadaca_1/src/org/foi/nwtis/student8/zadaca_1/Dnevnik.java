/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student8.zadaca_1;

import java.io.*;

/**
 *
 * @author nwtis_2
 */
public class Dnevnik {

    String datoteka;
    FileWriter dnv = null;
    BufferedWriter bw = null;

    public Dnevnik(String datoteka) {
        this.datoteka = datoteka;
        try {
            dnv = new FileWriter(this.datoteka, true);
            bw = new BufferedWriter(new FileWriter(datoteka, true));
        } catch (IOException ex) {
            System.out.println("Geska kod otvaranja datoteke" + ex.getMessage());
        }
    }

    public boolean upisi(String zapis) {
        try {
            bw.write(zapis);
            bw.newLine();
            bw.flush();
            return true;

        } catch (IOException ex) {
            System.out.println("Geska kod upisivanja u datotku" + ex.getMessage());
            return false;
        }
    }
}
