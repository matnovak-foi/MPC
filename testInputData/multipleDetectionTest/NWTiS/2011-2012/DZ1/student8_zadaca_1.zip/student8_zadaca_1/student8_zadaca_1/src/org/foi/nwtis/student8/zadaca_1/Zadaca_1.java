/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student8.zadaca_1;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.foi.nwtis.student8.konfiguracije.Konfiguracija;
import org.foi.nwtis.student8.konfiguracije.KonfiguracijaApstraktna;
import org.foi.nwtis.student8.konfiguracije.NemaKonfiguracije;

/**
 *
 * @author nwtis_2
 */
public class Zadaca_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String sintaksa = "^([^\\s]+\\.(?i)txt|xml)( +-load)?( +-noserver)?( +-nouser)?"
                + "( +-u +([^\\s]+))?( +-p +([^\\s]+))?"
                + "( +-ts +((?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)))?"
                + "( +-port +(6553[0-5]|655[0-2]\\d|65[0-4]\\d\\d|6[0-4]\\d{3}|[1-5]\\d{4}|[1-9]\\d{0,3}|0))?"
                + "( +-t +([0-3][0-9]+.+[0-1][0-9]+.+[1-2][0-9][0-9][0-9]+ * +[0-2][0-9]+:+[0-6][0-9]+:+[0-6][0-9])|( +-r))?"
                + "(( +PAUSE)|( +STOP)|( +START))?( +-s +([^\\s]+))? *$";

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < args.length; i++) {
            sb.append(args[i]).append(" ");
        }
        String p = sb.toString().trim();
        Pattern pattern = Pattern.compile(sintaksa);
        Matcher m = pattern.matcher(p);
        boolean status = m.matches();
        if (!status) {
            System.out.println("Parametri nisu korektno upisani!");
            return;
        } else {
            int poc = 0;
            int kraj = m.groupCount();
            for (int i = poc; i <= kraj; i++) {
                System.out.println(i + ". " + m.group(i));
            }
            String konfDatoteka = m.group(1);
            if (konfDatoteka == null) {
                System.out.println("Nema konfiguracijske datoteke");
                return;
            }
            Konfiguracija konfig = null;
            try {
                konfig = KonfiguracijaApstraktna.preuzmiKonfiguraciju(konfDatoteka);
            } catch (NemaKonfiguracije ex) {
                System.out.println("Nema konfiguracijske datoteke");
                return;
            }
            if (m.group(3) == null) {
                PokretacServerVremena psv = new PokretacServerVremena(konfig, m);
                psv.start();
            }
            if (m.group(4) == null) {
                PokretacKlijentVremena pkv = new PokretacKlijentVremena(konfig, m);
                pkv.start();
            }
            // ukoliko je upisano korisnicko ime, lozinka i (-t | -r)| (STOP | PAUSE | START)
            // pokreni AdministratoraVremena
            if (m.group(5) != null && m.group(7) != null && ((m.group(13) != null | m.group(15) != null) | m.group(16) != null)) {
                AdministratorVremena av = new AdministratorVremena(konfig, m);
                av.start();
            }
        }
    }
}
