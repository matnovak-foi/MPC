/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student8.zadaca_1;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.foi.nwtis.student8.konfiguracije.Konfiguracija;

/**
 *
 * @author nwtis_2
 */
public class ServerVremena extends Thread {

    private Socket klijent;
    private Konfiguracija konfig;
    private Matcher m;
    static int redniBrojDretve = 0;
    SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
    static List<Evidencija> evidencija = new ArrayList<>();
    String odgovor = "";

    public ServerVremena(Socket klijent, Konfiguracija konfig, Matcher m) {
        super("ServerVremena " + redniBrojDretve++);
        this.klijent = klijent;
        this.konfig = konfig;
        this.m = m;
    }

    @Override
    public void interrupt() {
        super.interrupt();
    }

    @Override
    public void run() {

        InputStream in = null;
        OutputStreamWriter out = null;

        try {
            in = klijent.getInputStream();
            StringBuilder sb = new StringBuilder();
            while (true) {
                int i = in.read();
                if (i == -1) {
                    break;
                } else {
                    sb.append((char) i);
                }
            }
            System.out.println("Komanda:" + sb);

            // RegEX za pristigle komande
            String sintaksa = "^([^\\s]+)( +[^\\s]+)( +[^\\s]+)( +[^\\s]+)?( +[^\\s]+)?( +[0-9\\s\\.\\:\\;]+)? *$";
            String p = sb.toString().trim();
            Pattern pattern = Pattern.compile(sintaksa);
            Matcher m = pattern.matcher(p);
            boolean status = m.matches();

            if (!status) {
                System.out.println("Parametri nisu korektno upisani!");
                return;
            } else {

                // ako je upisana jedna od 4 admin komande
                // kor. ime i lozinka za admina se provjeravaju u AdministratoruVremena 
                if (m.group(5) != null) {
                    if (m.group(5).trim().equals("PAUSE;")) {
                        PokretacServerVremena.pause = true;
                        odgovor = "OK ";
                    }
                    if (m.group(5).trim().equals("STOP;")) {
                        odgovor = "OK ";
                        PokretacServerVremena.stop = true;

                    }
                    if (m.group(5).trim().equals("START;")) {
                    }
                    if (m.group(5).trim().equals("SETTIME;")) {
                    }
                } else if (m.group(3).trim().equals("GETTIME;") && PokretacServerVremena.pause) {
                    // ako je komanda obicnog korisnika GETTIME dohvacena iz klijent vremena
                    odgovor = "OK " + sdf.format(new Date());

                }
            }

            Evidencija ev = new Evidencija(new Date(), sb.toString());
            evidencija.add(ev);

            out = new OutputStreamWriter(klijent.getOutputStream());
            out.write(odgovor);
            out.flush();
            klijent.shutdownOutput();
        } catch (IOException ex) {
            System.out.println("Greška kod izvođenja ServerVremena" + ex.getMessage());
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (IOException ex) {
                    System.out.println(this.getName() + " Problem kod zatvaranja io: " + ex.getMessage());
                }
            }
            if (out != null) {
                try {
                    out.close();
                } catch (IOException ex) {
                    System.out.println(this.getName() + " Problem kod zatvaranja out: " + ex.getMessage());
                }
            }
            if (klijent != null) {
                try {
                    klijent.close();
                } catch (IOException ex) {
                    System.out.println(this.getName() + " Problem kod zatvaranja klijent: " + ex.getMessage());
                }
            }
        }
    }

    @Override
    public synchronized void start() {
        super.start();
    }
}
