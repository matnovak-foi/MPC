/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student8.zadaca_1;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import org.foi.nwtis.student8.konfiguracije.Konfiguracija;

/**
 *
 * @author nwtis_2
 */
public class PokretacServerVremena extends Thread {

    private Konfiguracija konfig;
    private Matcher m;
    static boolean start = false;
    static boolean pause = false;
    static boolean stop = false;

    public PokretacServerVremena(Konfiguracija konfig, Matcher m) {
        super("PokretacServerVremena");
        this.konfig = konfig;
        this.m = m;
    }

    @Override
    public void interrupt() {
        super.interrupt();
    }

    @Override
    public void run() {
        String port = konfig.dajPostavku("port");

        if (port == null) {
            System.out.println("Ne postoji postavka port u konfiguraciji!");
            return;
        }
        try {
            ServerSocket ss = new ServerSocket(Integer.parseInt(port));
            while (true && stop == false) {
                Socket klijent = ss.accept();
                ServerVremena sv = new ServerVremena(klijent, konfig, m);
                sv.start();
                sleep(300);
            }
        } catch (InterruptedException ex) {
            Logger.getLogger(PokretacServerVremena.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            System.out.println("Greška kod startanja servera!" + ex.getMessage());
            return;
        }

    }

    @Override
    public synchronized void start() {
        super.start();
    }
}
