/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student8.zadaca_1;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Matcher;
import org.foi.nwtis.student8.konfiguracije.Konfiguracija;

/**
 *
 * @author nwtis_2
 */
public class KlijentVremena extends Thread {

    int brojDretve;
    private Konfiguracija konfig;
    private Matcher m;
    static int redniBrojDretve = 0;
    String ipadresa = "";
    int port = 0;
    String korisnik = "";
    int interval = 0;
    int brojPokusaja = 0;
    int maksBrojPokusaja = 0;
    String datoteka;
    SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
    String zapis = "";

    public KlijentVremena(int brojDretve, Konfiguracija konfig, Matcher m) {
        super("Dretva " + brojDretve);
        this.brojDretve = brojDretve;
        this.konfig = konfig;
        this.m = m;
        this.korisnik = m.group(6);
        // preuzmi ipadresu iz parametra -ts
        if (m.group(10) != null) {
            this.ipadresa = m.group(10);
        } else {
            System.out.println("nema ip adrese");
            return;
        }
        this.port = Integer.parseInt(m.group(12));
        this.datoteka = konfig.dajPostavku("dnevnik");
        this.interval = Integer.parseInt(konfig.dajPostavku("interval"));
        this.maksBrojPokusaja = Integer.parseInt(konfig.dajPostavku("brojPokusaja"));
    }

    @Override
    public void interrupt() {
        super.interrupt();
    }

    @Override
    public void run() {

        InputStream in = null;
        OutputStreamWriter out = null;
        Socket klijent = null;
        while (true) {
            // definiranje pocetka izvrsavanja dretve
            long pocetak = System.nanoTime();

            try {
                klijent = new Socket(ipadresa, port);
                in = klijent.getInputStream();
                out = new OutputStreamWriter(klijent.getOutputStream());

                out.write("USER " + korisnik + "; GETTIME;");
                out.flush();
                klijent.shutdownOutput();

                StringBuilder sb = new StringBuilder();
                while (true) {
                    int i = in.read();
                    if (i == -1) {
                        break;
                    } else {
                        sb.append((char) i);
                    }
                }
                System.out.println("Odgovor:" + sb);
                Dnevnik dnv = new Dnevnik(datoteka);
                dnv.upisi("Dretva " + this.brojDretve
                        + " Vlastito vrijeme: " + sdf.format(new Date())
                        + " Vrijeme servera: " + sdf.format(new Date())
                        + " Tekst poruke: " + sb);

            } catch (UnknownHostException ex) {
                this.brojPokusaja++;
            } catch (IOException ex) {
                this.brojPokusaja++;
            } finally {
                if (in != null) {
                    try {
                        in.close();
                    } catch (IOException ex) {
                        System.out.println(this.getName() + " Problem kod zatvaranja io: " + ex.getMessage());
                    }
                }
                if (out != null) {
                    try {
                        out.close();
                    } catch (IOException ex) {
                        System.out.println(this.getName() + " Problem kod zatvaranja out: " + ex.getMessage());
                    }
                }
                if (klijent != null) {
                    try {
                        klijent.close();
                    } catch (IOException ex) {
                        System.out.println(this.getName() + " Problem kod zatvaranja klijent: " + ex.getMessage());
                    }
                }
            }
            if (this.brojPokusaja >= this.maksBrojPokusaja) {
                System.out.println(this.getName() + " Prekoracen max broj pokusaja!");
                break;
            }

            // definiranje kraja izvrsavanja dretve
            long kraj = System.nanoTime();
            long utroseno = (kraj - pocetak) / 1000000;

            // korigirano vrijeme spavanja za vrijeme rada
            try {
                sleep(this.interval * 1000 - utroseno);
            } catch (InterruptedException ex) {
                System.out.println(this.getName() + " Prekid u spavanju: " + ex.getMessage());
                break;
            }
        }
    }

    @Override
    public synchronized void start() {
        // TODO upisi u dnevnik da je dretva startana
        super.start();
    }
}
