/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student8.zadaca_1;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.regex.Matcher;
import org.foi.nwtis.student8.konfiguracije.Konfiguracija;

/**
 *
 * @author nwtis_2
 */
public class AdministratorVremena extends Thread {

    private Konfiguracija konfig;
    private Matcher m;
    static int redniBrojDretve = 0;
    String ipadresa = "";
    int port = 0;
    String korisnik = "";
    String lozinka = "";
    String korisnikp = "";
    String lozinkap = "";

    public AdministratorVremena(Konfiguracija konfig, Matcher m) {
        this.konfig = konfig;
        this.m = m;
        this.korisnik = m.group(6); //korisnik iz argumenta
        this.ipadresa = m.group(10);
        this.lozinka = m.group(8); //lozinka iz argumenta
        this.port = Integer.parseInt(m.group(12));
        this.korisnikp = konfig.dajPostavku("admin"); //korisnik iz konfiguracije
        this.lozinkap = konfig.dajPostavku("lozinka"); //lozinka iz konfiguracije
    }

    @Override
    public void interrupt() {
        super.interrupt();
    }

    @Override
    public void run() {
        InputStream in = null;
        OutputStreamWriter out = null;
        Socket klijent = null;

        // provjera ispravnog korisnickog imena i lozinke
        if (korisnik.equals(korisnikp) && lozinka.equals(lozinkap)) {
            try {
                klijent = new Socket(ipadresa, port);
                in = klijent.getInputStream();
                out = new OutputStreamWriter(klijent.getOutputStream());

                if (m.group(14) != null) {
                    out.write("USER " + korisnik + "; PASSWD " + lozinka + "; SETTIME;");
                }

                if (m.group(17) != null) {
                    out.write("USER " + korisnik + "; PASSWD " + lozinka + "; PAUSE;");

                }
                if (m.group(19) != null) {
                    out.write("USER " + korisnik + "; PASSWD " + lozinka + "; START;");
                }
                if (m.group(18) != null) {
                    out.write("USER " + korisnik + "; PASSWD " + lozinka + "; STOP;");
                }

                out.flush();
                klijent.shutdownOutput();

                StringBuilder sb = new StringBuilder();
                while (true) {
                    int i = in.read();
                    if (i == -1) {
                        break;
                    } else {
                        sb.append((char) i);
                    }
                }
                System.out.println("Odgovor:" + sb);
                // TODO upisi u dnevnik

            } catch (UnknownHostException ex) {
            } catch (IOException ex) {
            } finally {
                if (in != null) {
                    try {
                        in.close();
                    } catch (IOException ex) {
                        System.out.println(this.getName() + " Problem kod zatvaranja io: " + ex.getMessage());
                    }
                }
                if (out != null) {
                    try {
                        out.close();
                    } catch (IOException ex) {
                        System.out.println(this.getName() + " Problem kod zatvaranja out: " + ex.getMessage());
                    }
                }
                if (klijent != null) {
                    try {
                        klijent.close();
                    } catch (IOException ex) {
                        System.out.println(this.getName() + " Problem kod zatvaranja klijent: " + ex.getMessage());
                    }
                }
            }
        } else {
            System.out.println("ERROR: Korisnicko ime i/ili lozinka su neispravno upisani");
        }
    }

    @Override
    public synchronized void start() {
        super.start();
    }
}
