/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student8.zadaca_1;

import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author nwtis_2
 */
public class Evidencija implements Serializable {

    private Date vrijeme;
    private String komanda;

    public Evidencija(Date vrijeme, String komanda) {
        this.vrijeme = vrijeme;
        this.komanda = komanda;
    }
}
