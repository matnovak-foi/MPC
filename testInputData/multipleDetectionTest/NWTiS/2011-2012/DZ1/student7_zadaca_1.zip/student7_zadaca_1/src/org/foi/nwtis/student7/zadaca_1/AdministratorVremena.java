/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student7.zadaca_1;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.regex.Matcher;
import org.foi.nwtis.student7.konfiguracije.Konfiguracija;

/**
 *
 * @author student7
 */
public class AdministratorVremena {

    Konfiguracija konfig;
    Matcher m;
    String ipadresa;
    int port = 0;
    String korisnik;
    String lozinka;
    static int redniBrojDretve = 0;
    SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");

    public AdministratorVremena(Konfiguracija konfig, Matcher m) {
        
        this.konfig = konfig;
        this.m = m;
        this.ipadresa = m.group(10);
        this.port = Integer.parseInt(m.group(12));
        this.korisnik = m.group(6);
        this.lozinka = m.group(8);
        
    }

    public void izvsi() {
        Socket klijent = null;
        InputStream in = null;
        OutputStreamWriter out = null;

        try {
            klijent = new Socket(ipadresa, port);
            in = klijent.getInputStream();
            out = new OutputStreamWriter(klijent.getOutputStream());
            out.write("USER " + korisnik + ";PASSWD" + lozinka + "; STOP;");
            out.flush();
            klijent.shutdownOutput();
            StringBuilder sb = new StringBuilder();
            while (true) {
                int i = in.read();
                if (i == -1) {
                    break;
                }
                sb.append((char) i);
            }
            System.out.println(sb);
        } catch (Exception ex) {
        } finally {
            try {
                if (in != null) {
                    in.close();
                }
            } catch (IOException ex) {
                System.out.println(this.getName() + " Problem kod zatvaranja in streama: " + ex.getMessage());
            }
            try {
                if (out != null) {
                    out.close();
                }
            } catch (IOException ex) {
                System.out.println(this.getName() + " Problem kod zatvaranja out streama: " + ex.getMessage());
            }
            try {
                if (klijent != null) {
                    klijent.close();
                }
            } catch (IOException ex) {
                System.out.println(this.getName() + " Problem kod zatvaranja socketa: " + ex.getMessage());
            }
        }
    }

    private String getName() {
        return this.toString();
    }
}
