/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student7.zadaca_1;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.foi.nwtis.student7.konfiguracije.Konfiguracija;
import org.foi.nwtis.student7.konfiguracije.KonfiguracijaApstraktna;
import org.foi.nwtis.student7.konfiguracije.NemaKonfiguracije;

/**
 *
 * @author student7
 */
public class Zadaca_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       // String sintaksa = "^([^\\s]+\\.(?i)txt|xml)( +-load)?( +-noserver)?( +-nouser)?( +-u +([^\\s]+))? *$";
        String sintaksa = "^([^\\s]+\\.(?i)txt|xml)( +-load)?( +-noserver)?( +-nouser)?( +-u +([^\\s]+))?( +-p +([^\\s]+))?( +-ts +((?:[01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.(?:[01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.(?:[01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.(?:[01]?\\d\\d?|2[0-4]\\d|25[0-5])))?( +-port +(\\d{1,50000}))?( +-t +((?:0?[1-9]|[12][0-9]|3[01]).(?:0?[1-9]|1[012]).(?:19|20\\d\\d)\\s(?:[01]?[0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9])| +-r)?( +PAUSE| +STOP| +START)?( +-s +([^\\s]+))? *$";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < args.length; i++) {
            sb.append(args[i]).append(" ");
        }
        
        String p = sb.toString().trim();
        Pattern pattern = Pattern.compile(sintaksa);
        Matcher m = pattern.matcher(p);
        boolean status = m.matches();
        
        if (!status) {
            System.out.println("Parametri nisu korektno upisani!");
            return;
        }

        int poc = 0;
        int kraj = m.groupCount();
        for (int i = poc; i <= kraj; i++) {
            System.out.println(i + ". " + m.group(i));
        }

        if (m.group(1) == null) {
            System.out.println("Nije upisana datoteka za konfiguraciju!");
            return;
        }

        String datotekaKonfig = m.group(1);
        Konfiguracija konfig;
        
        try {
            konfig = KonfiguracijaApstraktna.preuzmiKonfiguraciju(datotekaKonfig);
        } catch (NemaKonfiguracije ex) {
            System.out.println("Nema konfiguracijske datoteke! " + ex.getMessage());
            return;
        }

        if (konfig == null) {
            System.out.println("Nema konfiguracijske datoteke!");
            return;
        }
        
        if (m.group(3) == null) {
                if (m.group(2) != null) {
                    try {
                        ServerVremena.evidencija = Evidencija.ucitajEvidenciju(konfig);
                    } catch (Exception ex) {
                        System.out.println("Greska kod ucitavanja evidencije " + ex.getMessage());
                        return;
                    }
                }
                PokretacServerVremena psv = new PokretacServerVremena(konfig, m);
                psv.start();
            }

        //if (m.group(4) == null) {
        //    PokretacKlijentVremena pkv = new PokretacKlijentVremena(konfig, m);
        //    pkv.start();
        //}
        
        if (m.group(4) == null) {
                if (m.group(9) != null && m.group(11) != null) {
                    PokretacKlijentVremena pkv = new PokretacKlijentVremena(konfig, m);
                    pkv.start();
                } else {
                    System.out.println("Nekorektna ip adresa ili port servera vremena!");
                }

            }
        
        if (m.group(5) != null) {
            AdministratorVremena av = new AdministratorVremena(konfig, m);
            av.izvsi();
        }

    }
}
