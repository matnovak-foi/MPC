/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student7.zadaca_1;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.foi.nwtis.student7.konfiguracije.Konfiguracija;

/**
 *
 * @author student7
 */
public class Evidencija implements Serializable {
    private Date vrijeme;
    private String komanda;
    private String odgovor;

    public Evidencija(Date vrijeme, String komanda, String odgovor) {
        this.vrijeme = vrijeme;
        this.komanda = komanda;
        this.odgovor = odgovor;
    }
    
    public static ArrayList<Evidencija> ucitajEvidenciju(Konfiguracija konfig) throws Exception {
        FileInputStream in = null;
        try {
            in = new FileInputStream(konfig.dajPostavku("evidencija"));
            ObjectInputStream s = new ObjectInputStream(in);
            ArrayList<Evidencija> evidencija = (ArrayList<Evidencija>) s.readObject();
            return evidencija;
        } catch (IOException | ClassNotFoundException ex) {
            System.out.println("Greška kod otvaranje evidencije" + ex.getMessage());
            throw ex;
        } finally {
            try {
                in.close();
            } catch (IOException ex) {
                System.out.println("Greška kod otvaranje evidencije" + ex.getMessage());
                throw ex;
            }
        }
    }

    public static void exportEvidencija(Konfiguracija konfig, String datoteka) throws Exception {
        List<Evidencija> evidencija = ucitajEvidenciju(konfig);
        SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
        try {
            FileOutputStream fos = new FileOutputStream(datoteka, false);
            OutputStreamWriter os = new OutputStreamWriter(fos);
            BufferedWriter bw = new BufferedWriter(os);

            for (Evidencija e : evidencija) {

                bw.write(sdf.format(e.vrijeme) + ":");
                bw.newLine();
                bw.write("  Komanda: " + e.komanda);
                bw.newLine();
                bw.write("  Odgovor: " + e.odgovor);
                bw.newLine();

            }
            bw.close();
            os.close();
            fos.close();
        } catch (Exception ex) {
            throw ex;

        }

    }
        
}
