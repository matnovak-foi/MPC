/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student7.zadaca_1;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import org.foi.nwtis.student7.konfiguracije.Konfiguracija;


/**
 *
 * @author student7
 */
public class KlijentVremena extends Thread {

    Konfiguracija konfig;
    Matcher m;
    static int redniBrojDretve = 0;
    String ipadresa = null;
    int port = 0;
    int interval = 0;
    int brojPokusaja = 0;
    int maksBrojPokusaja = 0;
    SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
    String korisnik = "anonymous";

    public KlijentVremena(int brojDretve, Konfiguracija konfig, Matcher m) {
        super("Dretva " + redniBrojDretve++);
        this.konfig = konfig;
        this.m = m;
        this.ipadresa = m.group(10);
        this.port = Integer.parseInt(m.group(12));
        this.interval = Integer.parseInt(konfig.dajPostavku("interval"));
        this.maksBrojPokusaja = Integer.parseInt(konfig.dajPostavku("brojPokusaja"));        
        if (m.group(5) != null && m.group(6) != null) {
            this.korisnik = m.group(6);
        }
        System.out.println("Prijavljivanje: " + this.korisnik);
    }

    @Override
    public void interrupt() {
        super.interrupt();
    }

    @Override
    public void run() {
        InputStream in = null;
        OutputStreamWriter out = null;
        Socket klijent = null;
        while (true) {
            long poc = System.currentTimeMillis();
            try {
                
                klijent = new Socket(ipadresa, port);
                in = klijent.getInputStream();
                out = new OutputStreamWriter(klijent.getOutputStream());
                String upit = "USER " + korisnik + "; GETTIME;";
                out.write(upit);
                out.flush();
                klijent.shutdownOutput();

                StringBuilder sb = new StringBuilder();
                while (true) {
                    int i = in.read();
                    if (i == -1) {
                        break;
                    } else {
                        sb.append((char) i);
                    }
                }
                System.out.println("Odgovor:" + sb);
                Dnevnik dn = new Dnevnik(konfig.dajPostavku("dnevnik"));
                dn.upisi(sdf.format(new Date()) + ": " + this.getName() + "; Upit:" + upit + "; Odgovor:" + sb + ";");
                dn.zatvori();

            } catch (UnknownHostException ex) {
                this.brojPokusaja++;
            } catch (IOException ex) {
                this.brojPokusaja++;
            } finally {
                if (in != null) {
                    try {
                        in.close();
                    } catch (IOException ex) {
                        System.out.println(this.getName() + " Problem kod zatvaranja io: " + ex.getMessage());
                    }
                }
                if (out != null) {
                    try {
                        out.close();
                    } catch (IOException ex) {
                        System.out.println(this.getName() + " Problem kod zatvaranja out: " + ex.getMessage());
                    }
                }
                if (klijent != null) {
                    try {
                        klijent.close();
                    } catch (IOException ex) {
                        System.out.println(this.getName() + " Problem kod zatvaranja klijent: " + ex.getMessage());
                    }
                }
            }
            if (this.brojPokusaja >= this.maksBrojPokusaja) {
                System.out.println(this.getName() + " Prekoracen max broj pokusaja!");
                Dnevnik dn = new Dnevnik(konfig.dajPostavku("dnevnik"));
                dn.upisi(sdf.format(new Date()) + ": " + this.getName() + " Prekoracen max broj pokusaja");
                dn.zatvori();
                break;
            }
            try {
                long trajanje = System.currentTimeMillis() - poc;
                sleep(interval * 1000 - trajanje);
            } catch (InterruptedException ex) {
                System.out.println(this.getName() + " Prekid prilikom spavanja: " + ex.getMessage());
                break;
            }
        }
    }

    @Override
    public synchronized void start() {
        Dnevnik dn = new Dnevnik(konfig.dajPostavku("dnevnik"));
        dn.upisi(sdf.format(new Date()) + ": Pokrenuta " + this.getName());
        dn.zatvori();
        super.start();
    }
}
