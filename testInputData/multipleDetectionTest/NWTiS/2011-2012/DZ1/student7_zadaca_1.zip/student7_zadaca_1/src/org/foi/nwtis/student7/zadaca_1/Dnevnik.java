/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student7.zadaca_1;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

/**
 *
 * @author student7
 */
public class Dnevnik {
    String datoteka;
    BufferedWriter fos;

    public Dnevnik(String datoteka) {
        this.datoteka = datoteka;
        try {
            this.fos = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(datoteka, true)));
        } catch (IOException ex) {
            System.out.println("Pogreška prilikom otvaranja dnevnika!" + ex.getMessage());
        }
    }

    public boolean upisi(String zapis) {
        try {
            fos.write(zapis);
            fos.newLine();
            return true;
        } catch (IOException ex) {
            System.out.println("Pogreška prilikom pisanja u dnevnik!" + ex.getMessage());
            return false;
        }
    }
    
    public boolean zatvori() {
        try {
            fos.close();
            return true;
        } catch (IOException ex) {
            System.out.println("Pogreška prilikom zatvaranja dnevnika!" + ex.getMessage());
            return false;
        }
    }
    
}
