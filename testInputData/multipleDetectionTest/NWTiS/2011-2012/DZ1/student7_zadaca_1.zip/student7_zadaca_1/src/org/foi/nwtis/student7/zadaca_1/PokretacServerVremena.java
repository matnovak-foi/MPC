/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student7.zadaca_1;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.regex.Matcher;
import org.foi.nwtis.student7.konfiguracije.Konfiguracija;

/**
 *
 * @author student7
 */
public class PokretacServerVremena extends Thread {

    private Konfiguracija konfig;
    private Matcher m;
    
    ServerSocket ss = null;
    public static boolean isshutdown;

    public PokretacServerVremena(Konfiguracija konfig, Matcher m) {
        super("PokretacServerVremena");
        this.konfig = konfig;
        this.m = m;
    }

    @Override
    public void interrupt() {
        super.interrupt();
    }

    @Override
    public void run() {
        String port = konfig.dajPostavku("port");
        if (port == null) {
            System.out.println("Ne postoji postavka port u konfiguraciji!");
            return;
        }
        
        try {
            ss = new ServerSocket(Integer.parseInt(port));
            while (!isshutdown) {
                Socket klijent = ss.accept();
                ServerVremena sv = new ServerVremena(klijent, konfig, m, this);
                sv.start();
            }
        } catch (IOException ex) {
            System.out.println("Greška kod startanja servera!" + ex.getMessage());
            return;
        } finally {
            try {
                ss.close();
            } catch (IOException ex) {
                System.out.println("Greska kod zatvaranja socketa!");
            }
        }

    }
    
    public void shutdown(){
        this.isshutdown = true;
        try {
            ss.close();
        } catch (IOException ex) {
            System.out.println("GReska kod gasenja servera " + ex.getMessage());
        }
                
    }

    @Override
    public synchronized void start() {
        super.start();
    }
}
