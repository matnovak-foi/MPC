/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student7.zadaca_1;

import java.util.regex.Matcher;
import org.foi.nwtis.student7.konfiguracije.Konfiguracija;

/**
 *
 * @author student7
 */
public class PokretacKlijentVremena extends Thread {

    Konfiguracija konfig;
    Matcher m;

    public PokretacKlijentVremena(Konfiguracija konfig, Matcher m) {
        super("PokretacKlijentVremena");
        this.konfig = konfig;
        this.m = m;
    }

    @Override
    public void interrupt() {
        super.interrupt();
    }

    @Override
    public void run() {
        int brojDretvi = Integer.parseInt(konfig.dajPostavku("brojDretvi"));
        int pauza = Integer.parseInt(konfig.dajPostavku("pauza"));
        for (int i = 0; i < brojDretvi; i++) {
            KlijentVremena kv = new KlijentVremena(i, konfig, m);
            kv.start();
            try {
                Thread.sleep(pauza);
            } catch (InterruptedException ex) {
                System.out.println("Prekid kod pokretanja dretvi:" + ex.getMessage());
            }
        }
    }

    @Override
    public synchronized void start() {
        super.start();
    }
}
