/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student7.zadaca_1;

import java.io.*;
import java.net.Socket;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.foi.nwtis.student7.konfiguracije.Konfiguracija;

/**
 *
 * @author student7
 */
public class ServerVremena extends Thread {

    Socket klijent;
    Konfiguracija konfig;
    Matcher m;
    PokretacServerVremena psv = null;
    static long korekcijaVremena = 0;
    static int redniBrojDretve = 0;
    SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
    static List<Evidencija> evidencija = new ArrayList<>();
    private static boolean paused = false;
    

    public ServerVremena(Socket klijent, Konfiguracija konfig, Matcher m, PokretacServerVremena psv) {
        super("Server vremena " + redniBrojDretve++);
        this.klijent = klijent;
        this.psv = psv;
        this.konfig = konfig;
        this.m = m;
    }

    @Override
    public void interrupt() {
        super.interrupt();
    }

    @Override
    public void run() {
        InputStream in = null;
        OutputStreamWriter out = null;
        try {
            in = this.klijent.getInputStream();
            out = new OutputStreamWriter(this.klijent.getOutputStream());
            StringBuilder sb = new StringBuilder();
            while (true) {
                int i = in.read();
                if (i == -1) {
                    break;
                }
                sb.append((char)i);
            }
            
            System.out.println(sb);
            
            String sintaksa = "^(USER ([^\\s\\;]+)\\;)((GETTIME\\;)|(PASSWD ([^\\s\\;]+)\\;)(\\s(START|STOP|PAUSE|(SETTIME (([012]\\d|3[01]).(0\\d|1[012]).[0-9]{4} ([01]\\d|2[0-3]):[0-5]\\d:[0-5]\\d)))?\\;))?$";
            
            Pattern pattern = Pattern.compile(sintaksa);
            Matcher m2 = pattern.matcher(sb);
            boolean status = m2.matches();
            String odgovor = null;
            boolean issettime = false;
            Date oldtime = new Date(System.currentTimeMillis() + korekcijaVremena);
                       
            if (status) {
                if (m2.group(4) != null) {
                    if (!paused) {
                        odgovor = "OK " + sdf.format(new Date(System.currentTimeMillis() + korekcijaVremena));
                    } else {
                        odgovor = "";
                    }
                } else if (m2.group(8) != null) {
                    if (m2.group(2).equals(konfig.dajPostavku("admin")) && m2.group(6).equals(konfig.dajPostavku("lozinka"))) {
                        System.out.println("Komanda: " + m2.group(8));
                        switch (m2.group(8)) {
                            case "pokrenuti":
                                if (paused) {
                                    paused = false;
                                }
                                odgovor = "OK";
                                break;
                            case "zaustaviti":
                                odgovor = "OK";
                                Evidencija ev = new Evidencija(new Date(System.currentTimeMillis() + korekcijaVremena), sb.toString(), odgovor);
                                evidencija.add(ev);
                                FileOutputStream fos = new FileOutputStream(konfig.dajPostavku("evidencija"), false);
                                ObjectOutputStream s = new ObjectOutputStream(fos);
                                s.writeObject(evidencija);
                                s.close();
                                fos.close();
                                

                                psv.shutdown();
                                 
                                break;
                            case "pauzirati":
                                paused = true;
                                odgovor = "OK";
                                break;
                            default:
                                Date date;
                                try {
                                    date = sdf.parse(m2.group(10));
                                    korekcijaVremena = date.getTime() - System.currentTimeMillis();
                                    odgovor = "OK";
                                    issettime = true;
                                } catch (ParseException ex) {
                                    odgovor = "Pogrešan format vremena!";
                                }
                                
                                break;
                        }
                    } else {
                        odgovor = "Pogreška prilikom prikaza ograničenja administratora";
                    }
                }
            } else {
                odgovor = "Pogreška prilikom unosa komande";
            }
            out.write(odgovor);
            out.flush();
            Evidencija ev;
            if (issettime){
                ev = new Evidencija(oldtime, sb.toString(), odgovor);
            }else {
                ev = new Evidencija(new Date(System.currentTimeMillis() + korekcijaVremena), sb.toString(), odgovor);
            }
            evidencija.add(ev);
        } catch (IOException ex) {
            System.out.println("Pogreška kod ServeraVremena" + ex.getMessage());
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (IOException ex) {
                    System.out.println(this.getName() + " Problem zatvaranja io: " + ex.getMessage());
                }
            }
            if (out != null) {
                try {
                    out.close();
                } catch (IOException ex) {
                    System.out.println(this.getName() + " Problem zatvaranja out: " + ex.getMessage());
                }
            }
            if (klijent != null) {
                try {
                    klijent.close();
                } catch (IOException ex) {
                    System.out.println(this.getName() + " Problem zatvaranja klijent: " + ex.getMessage());
                }
            }

        }
    }

    @Override
    public synchronized void start() {
        super.start();
    }
}
