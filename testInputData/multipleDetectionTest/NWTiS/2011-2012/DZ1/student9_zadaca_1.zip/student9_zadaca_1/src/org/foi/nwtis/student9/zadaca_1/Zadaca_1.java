/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student9.zadaca_1;

import java.io.*;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.foi.nwtis.student9.konfiguracije.Konfiguracija;
import org.foi.nwtis.student9.konfiguracije.KonfiguracijaApstraktna;
import org.foi.nwtis.student9.konfiguracije.NemaKonfiguracije;

/**
 *
 * @author student9
 */
public class Zadaca_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //TODO modifikacija regexa za admine i ostalo sta bi trebalo
        //String sintaksa = "^([^\\s]+\\.(?i)txt|xml)( +-load)?( +-noserver)?( +-nouser)?( +-u +([^\\s]+))? *$"; // original
        String sintaksa = "^([^\\s]+\\.(?i)txt|xml)( +-load)?( +-noserver)?( +-nouser)?( +-u +([^\\s]+)( +-p +([^\\s]+))?)?( +-ts +([^\\s]+)( +-port +([\\d]+)))?((( +-t +((0?[1-9]|[12][0-9]|3[01])\\.(0?[1-9]|1[012])\\.((19|20)\\d\\d) ([01]?[0-9]|2[0-3]):[0-5][0-9]))|( +-r))|( +(PAUSE|START|STOP)))?( +-s +([^\\s]+))? *$";

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < args.length; i++) {
            sb.append(args[i]).append(" ");
        }
        String p = sb.toString().trim();
        Pattern pattern = Pattern.compile(sintaksa);
        Matcher m = pattern.matcher(p);
        boolean status = m.matches();

        if (!status) {
            System.out.println("Parametri nisu korektno upisani.");
            return;
        }

        if (status) {
            int poc = 0;
            int kraj = m.groupCount();
            for (int i = poc; i <= kraj; i++) {
                System.out.println(i + ". " + m.group(i));
            }

            String konfDatoteka = m.group(1);
            Konfiguracija konfig = null;

            if (konfDatoteka == null) {
                System.out.println("Nema konfiguracijske datoteke.");
                return;
            }

            try {
                konfig = KonfiguracijaApstraktna.preuzmiKonfiguraciju(konfDatoteka);
            } catch (NemaKonfiguracije ex) {
                System.out.println("Nema konfiguracijske datoteke.");
                return;
            }

            if (m.group(3) == null) {
                PokretacServerVremena psv = new PokretacServerVremena(konfig, m);
                psv.start();
            }

            if (m.group(4) == null) {
                PokretacKlijentVremena pkv = new PokretacKlijentVremena(konfig, m);
                pkv.start();
            }

            if (m.group(26) != null) {
                // serijaliziranu datoteku pretvorimo u citljvi oblik
                try {
                    InputStream file = new FileInputStream(konfig.dajPostavku("evidencija"));
                    InputStream buffer = new BufferedInputStream(file);
                    ObjectInput input = new ObjectInputStream(buffer);
                    try {
                        List<Evidencija> evidencija = (List<Evidencija>) input.readObject();

                        File fileD = new File(m.group(26));

                            if (!fileD.exists()) {
                                try {
                                    fileD.createNewFile();
                                } catch (IOException ex) {
                                    System.out.println("Datoteku nije moguce kreirati: " + ex.getMessage());
                                }
                            }

                            try {
                                FileOutputStream fos = new FileOutputStream(fileD);
                                
                                for (Evidencija ev : evidencija) {
                                    String str = "Komanda: " + ev.getKomnada() + System.lineSeparator();
                                    str += "Vrijeme: " + ev.getVrijeme() + System.lineSeparator();
                                    str += "Odgovor: " + ev.getOdgovor() + System.lineSeparator();
                                    str += "##############################################";
                                    fos.write(str.getBytes());
                                }
                                
                            } catch (FileNotFoundException ex) {
                                System.out.println("Greška s otvaranjem datoteke za pisanje: " + ex.getMessage());
                            }    

                    } finally {
                        input.close();
                    }
                } catch (ClassNotFoundException ex) {
                    System.out.println("Klasa nije pronađena. " + ex.getMessage());
                } catch (IOException ex) {
                    System.out.println("Greška kod deserijalicazije za zapis u datoteku. " + ex.getMessage());
                }
            }

        }
    }
}
