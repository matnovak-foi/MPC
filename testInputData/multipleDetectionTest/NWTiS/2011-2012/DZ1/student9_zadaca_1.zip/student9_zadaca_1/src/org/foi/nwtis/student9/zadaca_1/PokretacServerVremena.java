/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student9.zadaca_1;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.regex.Matcher;
import org.foi.nwtis.student9.konfiguracije.Konfiguracija;

/**
 *
 * @author student9
 */
public class PokretacServerVremena extends Thread {

    private Konfiguracija konfig;
    private Matcher m;

    public PokretacServerVremena(Konfiguracija konfig, Matcher m) {
        super("PokretacServerVremena");
        this.konfig = konfig;
        this.m = m;
    }

    @Override
    public void interrupt() {
        super.interrupt();
    }

    @Override
    public void run() {
        
        System.out.println("PSV treba biti pokrenut");

        String port = konfig.dajPostavku("port");
        if (port == null) {
            System.out.println("Ne postoji konfiguracija port.");
            return;
        }
        try {
            ServerSocket ss = new ServerSocket(Integer.parseInt(port));
            while (true) {
                Socket klijent = ss.accept();
                ServerVremena sv = new ServerVremena(klijent, konfig, m);
                sv.start();
            }
        } catch (IOException ex) {
            System.out.println("Greška kod startanja servera." + ex.getMessage());
            return;
        }
    }

    @Override
    public synchronized void start() {
        super.start();
    }
}
