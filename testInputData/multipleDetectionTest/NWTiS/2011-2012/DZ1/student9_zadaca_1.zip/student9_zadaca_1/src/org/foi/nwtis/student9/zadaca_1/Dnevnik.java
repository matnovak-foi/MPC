/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student9.zadaca_1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;


/**
 *
 * @author student9
 */
public class Dnevnik {
    private String datoteka;
    private FileOutputStream fos;
    private File file;

    public Dnevnik(String datoteka) {
        this.datoteka = datoteka;
        
        this.file = new File(this.datoteka);
        
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException ex) {
                System.out.println("Datoteku nije moguce kreirati: " + ex.getMessage());
            }
        }
        
        try {
            this.fos = new FileOutputStream(file, true);
        } catch (FileNotFoundException ex) {
            System.out.println("Greška s otvaranjem datoteke za pisanje: " + ex.getMessage());
        }
        
    }
    
    public synchronized boolean upisi(String zapis){
        zapis = zapis + System.lineSeparator();
        try {
            fos.write(zapis.getBytes());
            return true;
        } catch (IOException ex) {
            System.out.println("Neuspjelo pisanje u datoteku Dnevnika."  + ex.getMessage());
            return false;
        }
    }
    
    public boolean zatvori(){
        try {
            fos.close();
            return true;
        } catch (IOException ex) {
            System.out.println("Neuspjelo zatvaranje datoteke Dnevnika." + ex.getMessage());
            return false;
        }
    }
    
}
