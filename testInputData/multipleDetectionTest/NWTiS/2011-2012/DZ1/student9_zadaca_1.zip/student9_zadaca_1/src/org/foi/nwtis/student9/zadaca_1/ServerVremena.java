/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student9.zadaca_1;

import java.io.*;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import org.foi.nwtis.student9.konfiguracije.Konfiguracija;

/**
 *
 * @author student9
 */
public class ServerVremena extends Thread {

    private Socket klijent;
    private Konfiguracija konfig;
    private Matcher m;
    static int redniBrojDretve = 0;
    SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
    static List<Evidencija> evidencija = new ArrayList<>();

    ServerVremena(Socket klijent, Konfiguracija konfig, Matcher m) {
        super("ServerVremena" + redniBrojDretve++);
        this.klijent = klijent;
        this.konfig = konfig;
        this.m = m;
        if(m.group(2) != null){
            this.deserilizirajEvidenciju();
        }
    }

    @Override
    public void interrupt() {
        super.interrupt();
    }

    @Override
    public void run() {
        InputStream in = null;
        OutputStreamWriter out = null;
        try {
            System.out.println("ServerVremena pokrenut!");
            in = klijent.getInputStream();
            out = new OutputStreamWriter(klijent.getOutputStream());

            StringBuilder sb = new StringBuilder();

            while (true) {
                int i = in.read();
                if (i == -1) {
                    break;
                } else {
                    sb.append((char) i);
                }
            }
            System.out.println("Komanda: " + sb);
            //TODO: Ispis rezultata

            //TODO utvrdi koja komanda je u zahtjevu (Rijesiti preko RegEX)

            // TODO NOTICE! komanda SETTIME mora bitit static jer je za sve na razini klase, a GETTIME postojece vrijeme + pomak

            Evidencija ev = new Evidencija(new Date(), sb.toString());
            evidencija.add(ev);

            
            if (sb.toString().equals("STOP")) {
                System.out.println("Komanda je STOP");
                this.serilizirajEvidenciju();
            }

            //TODO zaustavi rad servera
            //TODO ako je pauza onda bi server trebao ignorirati korisnicke komande

            out.write("OK " + sdf.format(new Date()));
            out.flush();
            
            this.serilizirajEvidenciju();


        } catch (IOException ex) {
            System.out.println("Greška kod izvođenja ServerVremena. " + ex.getMessage());
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (IOException ex) {
                    System.out.println(this.getName() + ": greška kod zatvranja in. " + ex.getMessage());
                }
            }
            if (out != null) {
                try {
                    out.close();
                } catch (IOException ex) {
                    System.out.println(this.getName() + ": greška kod zatvranja out. " + ex.getMessage());
                }
            }
            if (klijent != null) {
                try {
                    klijent.close();
                } catch (IOException ex) {
                    System.out.println(this.getName() + ": greška kod zatvranja klijent. " + ex.getMessage());
                }
            }
        }

    }

    @Override
    public synchronized void start() {
        super.start();
    }

    public void serilizirajEvidenciju() {
        try {
            OutputStream file = new FileOutputStream(konfig.dajPostavku("evidencija"));
            OutputStream buffer = new BufferedOutputStream(file);
            ObjectOutput output = new ObjectOutputStream(buffer);
            try {
                output.writeObject(this.evidencija);
            } finally {
                output.close();
            }
        } catch (IOException ex) {
            System.out.println("Greška kod serijalicazije. " + ex.getMessage());
        }
    }

    public void deserilizirajEvidenciju() {
        try {
            InputStream file = new FileInputStream(konfig.dajPostavku("evidencija"));
            InputStream buffer = new BufferedInputStream(file);
            ObjectInput input = new ObjectInputStream(buffer);
            try {
                this.evidencija = (List<Evidencija>) input.readObject();               
            } finally {
                input.close();
            }
        } catch (ClassNotFoundException ex) {
            System.out.println("Klasa nije pronađena. " + ex.getMessage());
        } catch (IOException ex) {
            System.out.println("Greška kod deserijalicazije. " + ex.getMessage());
        }
    }

}
