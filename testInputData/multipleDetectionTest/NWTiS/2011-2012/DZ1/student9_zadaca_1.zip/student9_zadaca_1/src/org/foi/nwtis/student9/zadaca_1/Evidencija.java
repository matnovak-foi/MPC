/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student9.zadaca_1;

import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author student9
 */
public class Evidencija implements Serializable{
    private Date vrijeme;
    private String komnada;
    private String odgovor;

    public Evidencija(Date vrijeme, String komnada) {
        this.vrijeme = vrijeme;
        this.komnada = komnada;
    }    

    public void setOdgovor(String odgovor) {
        this.odgovor = odgovor;
    }

    public String getOdgovor() {
        return odgovor;
    }

    public String getKomnada() {
        return komnada;
    }

    public void setKomnada(String komnada) {
        this.komnada = komnada;
    }

    public Date getVrijeme() {
        return vrijeme;
    }

    public void setVrijeme(Date vrijeme) {
        this.vrijeme = vrijeme;
    }
    
    
    
    
    
}
