/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student9.zadaca_1;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Matcher;
import org.foi.nwtis.student9.konfiguracije.Konfiguracija;

/**
 *
 * @author student9
 */
public class KlijentVremena extends Thread {

    private Konfiguracija konfig;
    private Matcher m;
    static int redniBrojDretve = 0;
    String ipAdresa = "localhost";
    int port = 8000;
    String korisnik = "student9";
    int interval = 0;
    int brojPokusaja = 0;
    int maksBrojPokusaja = 0;
    SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");

    public KlijentVremena(Konfiguracija konfig, Matcher m) {
        super("Dretva " + redniBrojDretve++);
        this.konfig = konfig;
        this.m = m;
        this.interval = Integer.parseInt(konfig.dajPostavku("interval"));
        this.maksBrojPokusaja = Integer.parseInt(konfig.dajPostavku("brojPokusaja"));
        if(m.group(10) != null){
            this.ipAdresa = m.group(10);
        }
        if(m.group(12) != null){
            this.port = Integer.parseInt(m.group(12));
        }
        if(m.group(6) != null){
            this.korisnik = m.group(6);
        }
    }

    @Override
    public void interrupt() {
        super.interrupt();
    }

    @Override
    public void run() {
        InputStream in = null;
        OutputStreamWriter out = null;
        Socket klijent = null;
        Dnevnik dnevnik = new Dnevnik(konfig.dajPostavku("dnevnik"));

        while (true) {
            try {
                System.out.println("KlijentVremena pokrenut!");
                dnevnik.upisi(this.getName() + "; Vrijeme: " + sdf.format(new Date()) + "; Dretva je pokrenuta.");
                klijent = new Socket(ipAdresa, port);
                in = klijent.getInputStream();
                
                out = new OutputStreamWriter(klijent.getOutputStream());
                out.write("USER " + korisnik + "; GETTIME;");
                out.flush();
                klijent.shutdownOutput();

                StringBuilder sb = new StringBuilder();

                while (true) {
                    int i = in.read();
                    if (i == -1) {
                        break;
                    } else {
                        sb.append((char)i);
                    }
                }
                
                System.out.println("Odgovor: " + sb);
                dnevnik.upisi(this.getName() + "; Vrijeme: " + sdf.format(new Date()) + "; Odgovor: " + sb);

            } catch (UnknownHostException ex) {
                this.brojPokusaja++;
            } catch (IOException ex) {
                this.brojPokusaja++;
            } finally {
                if (in != null) {
                    try {
                        in.close();
                    } catch (IOException ex) {
                        System.out.println(this.getName() + ": greška kod zatvranja in. " + ex.getMessage());
                    }
                }
                if (out != null) {
                    try {
                        out.close();
                    } catch (IOException ex) {
                        System.out.println(this.getName() + ": greška kod zatvranja out. " + ex.getMessage());
                    }
                }
                if (klijent != null) {
                    try {
                        klijent.close();
                    } catch (IOException ex) {
                        System.out.println(this.getName() + ": greška kod zatvranja klijent. " + ex.getMessage());
                    }
                }
            }
            if(this.brojPokusaja >= this.maksBrojPokusaja){
                System.out.println(this.getName() + ": Prekoračen max broj pokusaja. ");
                dnevnik.upisi(this.getName() + ": Prekoračen max broj pokusaja. ");
                dnevnik.zatvori();
                break;
            }
            try {
                // ovdje dretva ide malo pajkiti
                sleep(interval * 1000);
            } catch (InterruptedException ex) {
                //TODO korigiraj vrijeme spavanje za vrijeme rada
                System.out.println(this.getName() + ": prekid u spavanju. " + ex.getMessage());
                break;
            }
        }

    }

    @Override
    public synchronized void start() {
        //TODO upisi u dnenivk da je dretva startana
        super.start();
    }
}
