/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student9.zadaca_1;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.regex.Matcher;
import org.foi.nwtis.student9.konfiguracije.Konfiguracija;

/**
 *
 * @author student9
 */
public class AdministratorVremena extends Thread {

    private Konfiguracija konfig;
    private Matcher m;
    static int redniBrojDretve = 0;
    String ipAdresa = "192.168.1.113";
    int port = 8000;
    String korisnik = "student9";
    String lozinka = "123456";

    public AdministratorVremena(Konfiguracija konfig, Matcher m) {
        this.konfig = konfig;
        this.m = m;
        this.ipAdresa = m.group(10);
        this.port = Integer.parseInt(m.group(12));
        this.korisnik = m.group(6);
        this.lozinka = m.group(8);
    }
    
    
    
    @Override
    public void interrupt() {
        super.interrupt();
    }

    @Override
    public void run() {
        
        InputStream in = null;
        OutputStreamWriter out = null;
        Socket klijent = null;

        while (true) {
            try {
                System.out.println("KlijentVremena pokrenut!");
                klijent = new Socket(ipAdresa, port);
                in = klijent.getInputStream();
                
                //TODO utvrdi koja je admin komanda 
                out = new OutputStreamWriter(klijent.getOutputStream());
                out.write("USER " + korisnik + "; PASSWD " + lozinka + "; STOP;");
                out.flush();
                klijent.shutdownOutput();

                StringBuilder sb = new StringBuilder();

                while (true) {
                    int i = in.read();
                    if (i == -1) {
                        break;
                    } else {
                        sb.append((char)i);
                    }
                }
                System.out.println("Odgovor: " + sb);
                //TODO upisi u dnevnik

            } catch (UnknownHostException ex) {
                System.out.println(this.getName() + ": greška. " + ex.getMessage());
            } catch (IOException ex) {
                System.out.println(this.getName() + ": greška. " + ex.getMessage());
            } finally {
                if (in != null) {
                    try {
                        in.close();
                    } catch (IOException ex) {
                        System.out.println(this.getName() + ": greška kod zatvranja in. " + ex.getMessage());
                    }
                }
                if (out != null) {
                    try {
                        out.close();
                    } catch (IOException ex) {
                        System.out.println(this.getName() + ": greška kod zatvranja out. " + ex.getMessage());
                    }
                }
                if (klijent != null) {
                    try {
                        klijent.close();
                    } catch (IOException ex) {
                        System.out.println(this.getName() + ": greška kod zatvranja klijent. " + ex.getMessage());
                    }
                }
            }
           
            
        }

    }

    @Override
    public synchronized void start() {
        super.start();
    }
    
}
