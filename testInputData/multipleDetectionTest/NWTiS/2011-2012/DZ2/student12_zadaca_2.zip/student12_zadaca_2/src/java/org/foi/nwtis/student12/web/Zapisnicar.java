/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student12.web;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import javax.servlet.ServletContext;

/**
 *
 * @author Administrator
 */
public class Zapisnicar extends Thread {

    public Integer interval;
    public Boolean radi = false;
    private ServletContext sc;
    public static final String DATE_FORMAT_SAD = "yyyyMMdd_HHmmss";

    public Zapisnicar(ServletContext sc) {
        super();   
        this.sc = sc;
        /**  
         *super poziva konstruktor klase thread
         */
    }

    @Override
    public void run() {
        try {
            while (radi.equals(Boolean.TRUE)) {
                napraviFolder();
                sleep(interval * 1000);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void setRadi(Boolean val) {
        this.radi = val;
    }

    public static String vrijemeSad() {
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_SAD);
        return sdf.format(cal.getTime());
    }

    public void napraviFolder() {
        String path = sc.getRealPath("/"); 
        /**
         *Putanja koja se dobije iz servlet konteksta je relativna putanja koja nam ne koristi ako želimo radit sa fileovima.
         *Zato nam treba apsolutna putanja.       
         
         */
        interval = Integer.parseInt(sc.getInitParameter("interval")); 
        File f = new File(path + "zapisi");

        /**  
         *kreiranje direktorija
         */
        if (f.exists()) {
            System.out.println("Direktorij ZAPISI vec je kreiran!");
        } else {
            f.mkdir();
            System.out.println("Direktorij ZAPISI je kreiran!");
        }

        //zapisuje fajl
        try {
            BufferedWriter out = new BufferedWriter(new FileWriter(f.getPath() + "/datoteka_" + vrijemeSad() + ".txt"));
            out.write("Zapis!");
            System.out.println("Zapis je kreiran!");
            out.close();
        } catch (IOException e) {
            System.out.println(e);
        }
    }

}
