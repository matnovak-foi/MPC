/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student12.web;

/**
 *
 * @author nwtis_3
 */
public class DodajKorisnikaPogreska extends Exception {

   

    /**
     * Constructs an instance of
     * <code>DodajKorisnikaPogreska</code> with the specified detail message.
     *
     * @param msg the detail message.
     */
    public DodajKorisnikaPogreska(String msg) {
        super(msg);
    }
}
