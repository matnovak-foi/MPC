/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student12.web;

/**
 *
 * @author nwtis_3
 */
public class AzurirajKorisnikaPogreska extends Exception {

    /**
     * Creates a new instance of
     * <code>AzurirajKorisnikaPogreska</code> without detail message.
     */
    public AzurirajKorisnikaPogreska() {
    }

    /**
     * Constructs an instance of
     * <code>AzurirajKorisnikaPogreska</code> with the specified detail message.
     *
     * @param msg the detail message.
     */
    public AzurirajKorisnikaPogreska(String msg) {
        super(msg);
    }
}
