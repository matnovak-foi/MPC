/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student12.web.slusaci;

import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import org.foi.nwtis.student12.konfiguracije.NemaKonfiguracije;
import org.foi.nwtis.student12.konfiguracije.bp.BP_Konfiguracija;

/**
 * Web application lifecycle listener.
 *
 * @author nwtis_3
 */
public class SlusacAplikacije implements ServletContextListener {

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        ServletContext sc = sce.getServletContext();
        String path = sc.getRealPath("WEB-INF");
        String datoteka = path + java.io.File.separator + sc.getInitParameter("konfiguracija");
        BP_Konfiguracija bp = null;
        try {
            bp = new BP_Konfiguracija(datoteka);
            sc.setAttribute("BP_Konfiguracija", bp);
        } catch (NemaKonfiguracije ex) {
            System.out.println("Nema konfiguracije!");
            return;
        }

    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
    }
  
    
    /* 
     
     
   broj aktivnih sesija
   * 
<%
Integer icount = (Integer)session.getAttribute("count");
out.println("total live sessions "+icount);
%>



import javax.servlet.*;
import javax.servlet.http.*;

public final class CounterListener implements HttpSessionListener
    {
     private int count = 1;
     private ServletContext context = null;
    
     public synchronized void sessionCreated(HttpSessionEvent se)
         {
         count++;
         log("sessionCreated("+se.getSession().getId()+") count="+count);
         se.getSession().setAttribute("count",new Integer(count));
     }
    
     public synchronized void sessionDestroyed(HttpSessionEvent se)
         {
         count--;
         log("sessionDestroyed("+se.getSession().getId()+") count="+count);
         se.getSession().setAttribute("count",new Integer(count));
     }
    
     public int getCount()
         {
         return this.count;
     }
    
     public void addCount()
         {
         count++;
     }
    
     private void log(String message)
         {
         if (context != null)
         context.log("SessionListener: " + message);
         else
         System.out.println("SessionListener: " + message);
     }
    
}
     
     
     
     */
    
   
}
