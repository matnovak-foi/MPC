/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student12.web.kontrole;

/**
 *
 * @author Administrator
 */
public class Korisnik {
    
}
