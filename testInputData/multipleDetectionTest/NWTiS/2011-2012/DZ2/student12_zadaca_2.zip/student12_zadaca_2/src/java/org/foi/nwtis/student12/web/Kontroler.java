/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student12.web;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Administrator
 */
public class Kontroler extends HttpServlet {

    /**
     * Processes requests for both HTTP
     * <code>GET</code> and
     * <code>POST</code> methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, DodajKorisnikaPogreska {

        String zahtjev = request.getServletPath();
        String nastavi = null;

        switch (zahtjev) {
            case "/Kontroler":
                nastavi = "/jsp/index.jsp";
                break;


            case "/RegistracijaKorisnika":
                nastavi = "/jsp/registracijaKorisnika.jsp";
                break;

            case "/DodajKorisnika":
                try {
                    // TO DO dovrši prema opisu zadaće

                    Connection konekcija = DriverManager.getConnection("jdbc:mysql://localhost:3306/nwtis_g3", "nwtis_g3", "g3_nwtis");
                    Statement stm = konekcija.createStatement();


                    String Ime = request.getParameter("Ime");
                    String Prezime = request.getParameter("Prezime");
                    String korisnickoIme = request.getParameter("korisnickoIme");
                    String lozinka = request.getParameter("lozinka");
                    String lozinkaP = request.getParameter("lozinkaP");
                    String email = request.getParameter("email");
                    Date dreg = new Date();
                    Timestamp treg = new Timestamp(dreg.getTime());

                    if (lozinka == lozinkaP) {

                        if (Ime.length() == 0 || Prezime.length() == 0 || korisnickoIme.length() < 6 || lozinka.length() < 6 || email.length() == 0) {
                           
                            throw new org.foi.nwtis.student12.web.DodajKorisnikaPogreska("Greška prilikom unosa podataka, molimo ponovite!");
                        } else {

                            String provjera = "SELECT COUNT(kor_ime) FROM polaznici WHERE kor_ime='korisnickoIme'";
                            ResultSet rs = stm.executeQuery(provjera);
                           
                            if (rs.next()) {
                                if (Integer.parseInt(rs.getString("kor_ime")) != 0) {
                                    
                                    throw new org.foi.nwtis.student12.web.DodajKorisnikaPogreska("Korisnicko ime zauzeto, odaberite novo!");
                                } else {
                                    
                                    String unos = "INSERT INTO polaznici (kor_ime, ime, prezime,lozinka, email_adresa, vrsta, datum_kreiranja) VALUES ('" + korisnickoIme + "','" + Ime + "', '" + Prezime + "', '" + lozinka + "', '" + email + "', '1', '" + treg + "')";
                                }
                            } else {
                               
                                throw new org.foi.nwtis.student12.web.DodajKorisnikaPogreska("Nešto ne radi!");
                            }
                        }

                    } else {
                       
                        throw new org.foi.nwtis.student12.web.DodajKorisnikaPogreska("Greška prilikom unosa podataka, molimo ponovite!");

                    }



                } catch (SQLException ex) {
                    System.out.println("Pogreška kod spajanja na bazu" + ex.getMessage());
                }




                break;

            case "/AzurirajKorisnika":
                // TO DO izbacuje formular sa popunjenim podacima aktivnog korisnika, on ih moze promijeniti (samo svoje)
                break;

            case "/PrijavaKorisnika":
                nastavi = "/jsp/login.jsp";
                break;

            case "/OdjavaKorisnika":
                //to do session destroy?
                nastavi = "/Kontroler";
                break;


            case "/ProvjeraKorisnika":
                // TO DO dovrši prema opisu zadaće
//                    String provjeraLog = "SELECT COUNT(kor_ime) FROM polaznici WHERE kor_ime='korisnickoIme'";
//                     if (rs.next()) {
//                                if (Integer.parseInt(rs.getString("kor_ime")) != 0) {
//                                   nastavi = "/admin/ispisKorisnika_1.jsp";
//                                } else {
//                                    System.out.println("Pogrešni ");
//                                  }
//                            } else {
//                                System.out.println("neki vrag");
//                                throw new org.foi.nwtis.student12.web.DodajKorisnikaPogreska("Nešto ne radi!");
//                            }           
//                
                break;


            case "/IspisAktivnihKorisnika":
                nastavi = "/admin/ispisAktivnihKorisnika.jsp";
                break;


            case "/IspisKorisnika_1":
                nastavi = "/admin/ispisKorisnika_1.jsp";
                break;
            case "/IspisKorisnika_2":
                nastavi = "/admin/ispisKorisnika_2.jsp";
                break;
            case "/IspisKorisnika_3":
                nastavi = "/admin/ispisKorisnika_3.jsp";
                break;

            case "/IspisPodataka":
                nastavi = "/privatno/ispisPodataka.jsp";
                break;






        }

        if (nastavi == null) {
            System.out.println("Nepoznati zahtjev!");
            return;
        }

        RequestDispatcher rd = this.getServletContext().getRequestDispatcher(nastavi);
        rd.forward(request, response);
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP
     * <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (DodajKorisnikaPogreska ex) {
            Logger.getLogger(Kontroler.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP
     * <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (DodajKorisnikaPogreska ex) {
            Logger.getLogger(Kontroler.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
