/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student10.web.kontrole;

/**
 *
 * služi za pohranu podataka o korisnicima
 *
 * @param String korisnik; id korisnika
 * @param String prezime; prezime korisnika
 * @param String ime; ime korisnika
 * @param String ses_ID; id sesije korisnika
 * @param int vrsta; vrste korisnika
 *
 * @author npzaweb_admin
 */
public class Korisnik {

    String korisnik;
    String prezime;
    String ime;
    String ses_ID;
    int vrsta;

    /**
     *
     * konstruktor klase korisnik
     *
     * @param String korisnik; id korisnika
     * @param String prezime; prezime korisnika
     * @param String ime; ime korisnika
     * @param String ses_ID; id sesije korisnika
     * @param int vrsta; vrste korisnika
     */
    public Korisnik(String korisnik, String prezime, String ime, String ses_ID, int vrsta) {
        this.korisnik = korisnik;
        this.prezime = prezime;
        this.ime = ime;
        this.ses_ID = ses_ID;
        this.vrsta = vrsta;
    }

    /**
     * 
     * @return vraca ime korisnika 
     */
    
    public String getIme() {
        return ime;
    }

    /**
     * 
     * @param ime postavlja ime korisnika
     */
    
    public void setIme(String ime) {
        this.ime = ime;
    }

    /**
     * 
     * @return vraca korisnicko ime korisnika
     */
    
    public String getKorisnik() {
        return korisnik;
    }

    /**
     * 
     * @param korisnik postavlja korisnicko ime korisnika 
     */
    
    public void setKorisnik(String korisnik) {
        this.korisnik = korisnik;
    }

    /**
     * 
     * @return vraca prezime korisnika 
     */
    
    public String getPrezime() {
        return prezime;
    }

    /**
     * 
     * @param prezime postavlja prezime korisnika 
     */
    
    public void setPrezime(String prezime) {
        this.prezime = prezime;
    }

    /**
     * 
     * @return vraca id sesije korisnika 
     */
    
    public String getSes_ID() {
        return ses_ID;
    }

    /**
     * 
     * @param ses_ID postavlja id sesije korisnika 
     */
    
    public void setSes_ID(String ses_ID) {
        this.ses_ID = ses_ID;
    }

    /**
     * 
     * @return vraca vrstu korisnika 
     */
    
    public int getVrsta() {
        return vrsta;
    }

    /**
     * 
     * @param vrsta postavlja vrstu korisnika 
     */
    
    public void setVrsta(int vrsta) {
        this.vrsta = vrsta;
    }
}
