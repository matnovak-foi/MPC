/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student10.web;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.apache.catalina.Session;
import org.apache.catalina.core.ApplicationContext;
import org.foi.nwtis.student10.web.slusaci.SlusacAplikacije;
import org.foi.nwtis.mjurisic.konfiguracije.Konfiguracija;
import org.foi.nwtis.mjurisic.konfiguracije.KonfiguracijaApstraktna;
import org.foi.nwtis.mjurisic.konfiguracije.NemaKonfiguracije;

/**
 *
 * @author student10
 */
public class Zapisnicar extends Thread {

    Konfiguracija konfig = null;
    SimpleDateFormat sdf = new SimpleDateFormat("yyyddMM_HHmmss");
    Calendar cal = Calendar.getInstance();
    String imeDatoteke = "";
    private FileOutputStream fos;

    @Override
    public void interrupt() {
        super.interrupt();
    }

    @Override
    public void run() {

//        try {
//            konfig = KonfiguracijaApstraktna.preuzmiKonfiguraciju("NWTiS_zadaca_2.txt");
//        } catch (NemaKonfiguracije ex) {
//            System.out.println("Pogreska kod ucitavanje konfiguracije");
//        }
        //TODO ucitati parametre intervala
        //int interval = Integer.parseInt(konfig.dajPostavku("interval"));

        //provjeriti da li postoji stvoren dir /zapisi
/*
        String path ="/zapisi/";
        ClassLoader loader = Thread.currentThread().getContextClassLoader();
        try {
            String path22 = loader.getResource("/").toURI().getPath();
            System.out.println(path22);
        } catch (URISyntaxException ex) {
            Logger.getLogger(Zapisnicar.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        File direktorij = new File(path);
        if (!direktorij.exists()) {
            direktorij.mkdir();
        }
        // (postavka datoteka)_yyyyMMdd_hhmmss.txt
        while (true) {
            String zapis = "student10";
            //System.out.println("Sada je: " + new Date());
            imeDatoteke = "NWTiS_zadaca_2_" + sdf.format(new Date()) + ".txt";
            System.out.println(SlusacAplikacije.korisnici.get("ime"));
            System.out.println(imeDatoteke);
            try {
                fos = new FileOutputStream(path + imeDatoteke,true);
            } catch (FileNotFoundException ex) {
                System.out.println("Pogreska kod otvaranja datoteke");
            }
            try {
                fos.write(zapis.getBytes());
            } catch (IOException ex) {
                System.out.println("Pogreska kod pisanja datoteke");
            }
            try {
                fos.close();
            } catch (IOException ex) {
                System.out.println("Pogreska kod zatvaranja datoteke");
            }
            try {
                this.sleep(1000);
            } catch (InterruptedException ex) {
                System.out.println("Pogreska kod spavanja");
                break;
            }
        }

*/
    }

    @Override
    public synchronized void start() {
        super.start();
    }
}
