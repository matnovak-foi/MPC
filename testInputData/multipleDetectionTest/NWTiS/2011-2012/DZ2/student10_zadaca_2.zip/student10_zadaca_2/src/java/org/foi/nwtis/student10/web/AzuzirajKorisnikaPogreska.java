/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student10.web;

/**
 *
 * @author student10
 * 
 * ta klasa se aktivira ako se dogodi pogreska kod azuriranja korisnika
 * svaka pogreska kod azuriranja throws ovu klasu iznimke
 * 
 */
public class AzuzirajKorisnikaPogreska extends Exception {

    /**
     * Creates a new instance of
     * <code>AzuzirajKorisnikaPogreska</code> without detail message.
     */
    public AzuzirajKorisnikaPogreska() {
    }

    /**
     * Constructs an instance of
     * <code>AzuzirajKorisnikaPogreska</code> with the specified detail message.
     *
     * @param msg the detail message.
     */
    public AzuzirajKorisnikaPogreska(String msg) {
        super(msg);
    }
}
