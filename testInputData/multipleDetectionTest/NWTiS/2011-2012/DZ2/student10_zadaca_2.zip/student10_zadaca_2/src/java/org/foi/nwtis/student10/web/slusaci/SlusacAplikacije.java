/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student10.web.slusaci;

import java.util.LinkedHashMap;
import java.util.Map;
import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import org.foi.nwtis.student10.konfiguracije.bp.BP_Konfiguracija;

 /**
  * 
 * inicijalna metoda
 * spremamo objekt u atribut konteksta pod kljucem BP_konfiguracija
 * 
 * @param  ServletContext sc         stvaranje konteksta
 * @param  String path               dobivanje putanje do WEB-INF direktorija
 * @param  String konfDatoteka       dobivanje putanje do konfig datoteke iz inicijalnog parametara konteksta
 * @param  BP_Konfiguracija bp       ucitavanje konfiguracije iz konfigDatoteke
 * @param korisnici                  mapa korisnika u koju se spremaju svi aktivni korisnici
 * @param broj                       trenutan broj aktivnih korisnika
 *  
 */


public class SlusacAplikacije implements ServletContextListener {

   public static  Map<String,Object> korisnici;
   
   public static int broj = 0;
    
   /**
    * 
    * pokrece se kod pokretanja aplikacije
    * postavlja objekt konfiguracije u atribut konteksta
    * 
    * @param sce 
    * @param sc kontekst 
    * @param putanja do WEB-INF dir
    * @param konfDatoteke konfig datoteka
    */
   
    @Override
    public void contextInitialized(ServletContextEvent sce) {
        ServletContext sc = sce.getServletContext();
        String path = sc.getRealPath("WEB-INF") + java.io.File.separator;
        String konfDatoteka = path + sc.getInitParameter("konfiguracija");
        
        if(sc.getAttribute("popisKorisnika") == null) {
        korisnici = new LinkedHashMap<String, Object>();
        }
        
        //ucitavanje podataka konfiguracije
        BP_Konfiguracija bp = new BP_Konfiguracija(konfDatoteka);
        if(bp.getStatus()) {
            //postavljanje ucitanih podataka u atribut konteksta BP_konfiguracija
             //spremili smo cijeli objekt
            sc.setAttribute("BP_konfiguracija", bp);
        }
        
    }

    /**
     * Ispisuje na konzolu kraj kod zatvaranja aplikacije
     * @param sce 
     */
    
    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        System.out.println("Kraj");
    }


    
    
}
