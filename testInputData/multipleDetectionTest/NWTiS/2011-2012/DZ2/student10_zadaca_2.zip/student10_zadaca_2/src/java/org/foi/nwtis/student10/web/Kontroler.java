/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student10.web;

import java.sql.*;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.foi.nwtis.student10.konfiguracije.bp.BP_Konfiguracija;
import org.foi.nwtis.student10.web.kontrole.Korisnik;

/**
 *
 * @author student10
 *
 * ova klasa zaprima sve zahtjeve te preusmjerava prema zahtjevima
 *
 */
public class Kontroler extends HttpServlet {

    /**
     * Processes requests for both HTTP
     * <code>GET</code> and
     * <code>POST</code> methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @param zahtjev dohvaća putanju servleta (zahtjeva)
     * @param odrediste varijabla koja poprima adresu preusmjerenja
     * @param Korisnik korisnik2 instanciranje objekta klase korisnik koja služi
     * kao objekt za spremanje podataka o korisniku
     * @param kor_ime i svaka varijanta koja sadrzi u sebi kor_ime je varijabla
     * u koju se spremaju podaci procirani iz forme
     * @param ime i svaka varijanta koja sadrzi u sebi ime je varijabla u koju
     * se spremaju podaci procirani iz forme
     * @param prezime i svaka varijanta koja sadrzi u sebi prezime je varijabla
     * u koju se spremaju podaci procirani iz forme
     * @param lozinka i svaka varijanta koja sadrzi u sebi lozinka je varijabla
     * u koju se spremaju podaci procirani iz forme
     * @param email_adresa i svaka varijanta koja sadrzi u sebi email_adresa je
     * varijabla u koju se spremaju podaci procirani iz forme
     * @param vrsta i svaka varijanta koja sadrzi u sebi vrsta je varijabla u
     * koju se spremaju podaci procirani iz forme
     * @param datum_kreiranja i svaka varijanta koja sadrzi u sebi
     * datum_kreiranja je varijabla u koju se spremaju podaci procirani iz forme
     * @param datum_promjene i svaka varijanta koja sadrzi u sebi datum_promjene
     * je varijabla u koju se spremaju podaci procirani iz forme
     * <code> HttpSession sesija2 = request.getSession(false) </code> dohvaća
     * samo id trenutne sesije korisnika
     * @param datoteka je putanja do datoteke konfiguracije
     * @param BP_Konfiguracija bp to je instanca klase BP_konfiguracija za
     * konfig baze podataka
     * @param connURL putanja do drivera za bazu
     * @param Connection conn konekcija na bazu
     * @param Statement stmt kreiranje statementa za upit
     * @param ResultSet rs to je set koji sadrži rezultat upita
     * @param RequestDispatcher rd priprema za preusmjeravanje na zahtijevani
     * servlet
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        String zahtjev = request.getServletPath();
        String odrediste = null;
        Korisnik korisnik2 = null;

        switch (zahtjev) {

            case "/Kontroler":
                odrediste = "/jsp/index.jsp";
                break;
            case "/RegistracijaKorisnika":
                odrediste = "/jsp/registracijaKorisnika.jsp";
                break;
            case "/DodajKorisnika":
                String kor_ime = request.getParameter("kor_ime");
                String ime = request.getParameter("ime");
                String prezime = request.getParameter("prezime");
                String lozinkaa = request.getParameter("lozinka");
                String email_adresa = request.getParameter("email_adresa");
                String vrsta = request.getParameter("vrsta");
                String datum_kreiranja = request.getParameter("datum_kreiranja");
                String datum_promjene = request.getParameter("datum_promjene");
                try {
                    this.dodajKorisnika(kor_ime, ime, prezime, lozinkaa, email_adresa);
                } catch (DodajKorisnikaPogreska ex) {
                    //odrediste = "/jsp/dodajKorisnikaPogreska.jsp";
                    return;
                }
                odrediste = "/jsp/login.jsp";

                break;
            case "/AzurirajKorisnika":
                String novo_kor_ime = request.getParameter("novo_kor_ime");
                String novo_ime = request.getParameter("novo_ime");
                String novo_prezime = request.getParameter("novo_prezime");
                String novo_vrsta = request.getParameter("novo_vrsta");
                try {
                    this.azurirajKorisnika(novo_kor_ime, novo_ime, novo_prezime, novo_vrsta);
                } catch (AzuzirajKorisnikaPogreska ex) {
                    //TODO pogreska
                }
                odrediste = "/privatno/ispisPodataka.jsp";
                break;
            case "/AzurirajKorisnik":
                odrediste = "/privatno/azurirajKorisnika.jsp";
                break;
            case "/PrijavaKorisnika":
                odrediste = "/jsp/login.jsp";
                break;
            case "/OdjavaKorisnika":
                HttpSession sesija2 = request.getSession(false);
                if (sesija2 != null) {
                    sesija2.invalidate();
                    //odrediste = "/jsp/index.jsp";
                }
                break;
            case "/ProvjeraKorisnika":

                String path = getServletContext().getRealPath("WEB-INF");
                String datoteka = path + java.io.File.separator + getServletContext().getInitParameter("konfiguracija");
                BP_Konfiguracija bp = new BP_Konfiguracija(datoteka);
                String connURL = bp.getServer_database() + bp.getUser_database();
                Connection conn = null;
                Statement stmt = null;
                ResultSet rs = null;

                try {
                    Class.forName(bp.getDriver_database());
                } catch (ClassNotFoundException ex) {
                    System.out.println("Greska kod spajanja na bazu " + ex.getMessage());
                }

                String korisnik = request.getParameter("korIme");
                String lozinka = request.getParameter("lozinka");

                if (korisnik == null || korisnik.length() == 0 || lozinka == null || lozinka.length() == 0) {
                    //pogeska - preusmjeravanje
                    break;
                }

                String sql = "SELECT kor_ime,lozinka,ime,prezime,vrsta,email_adresa FROM polaznici";
                if (bp.getStatus()) {
                    try {
                        conn = DriverManager.getConnection(connURL, bp.getUser_username(), bp.getUser_password());
                        stmt = conn.createStatement();
                        rs = stmt.executeQuery(sql);
                        while (rs.next()) {
                            String kor_ime2 = rs.getString("kor_ime");
                            String lozinka2 = rs.getString("lozinka");
                            String ime2 = rs.getString("ime");
                            String prezime2 = rs.getString("prezime");
                            int vrsta2 = Integer.parseInt(rs.getString("vrsta"));
                            String email_adresa2 = rs.getString("email_adresa");

                            if (korisnik.equals(kor_ime2) && lozinka.equals(lozinka2)) {
                                HttpSession sesija = request.getSession();
                                korisnik2 = new Korisnik(kor_ime2, prezime2, ime2, sesija.getId(), vrsta2);
                                sesija.setAttribute("korisnik", korisnik2);
//                                 sesija.setAttribute(kor_ime2, "korisnik");
//                                 sesija.setAttribute(ime2, "ime");
//                                 sesija.setAttribute(prezime2, "prezime");
//                                 sesija.setAttribute(email_adresa2, "email_adresa");
//                                 sesija.setAttribute(vrsta2, "vrsta");

                                odrediste = "/admin/ispisKorisnika_1.jsp";
                            }
                        }
                    } catch (SQLException ex) {
                        //neuspjesno spajanje na bazu
                        System.out.println("Niste se spojili na bazu" + ex.getMessage());
                        break;
                    } finally {
                        try {
                            rs.close();
                        } catch (SQLException ex) {
                        }
                        try {
                            stmt.close();
                        } catch (SQLException ex) {
                        }
                        try {
                            conn.close();
                        } catch (SQLException ex) {
                        }
                    }
                }

                break;
            case "/IspisAktivnihKorisnika":
                odrediste = "/admin/ispisAktivnih_korisnika.jsp";
                break;
            case "/IspisKorisnika_1":
                odrediste = "/admin/ispisKorisnika_1.jsp";
                break;
            case "/IspisKorisnika_2":
                odrediste = "/admin/ispisKorisnika_2.jsp";
                break;
            case "/IspisKorisnika_3":
                odrediste = "/admin/ispisKorisnika_3.jsp";
                break;
            case "/IspisPodataka":
                odrediste = "/privatno/ispisPodataka.jsp";
                break;

        }

        if (odrediste == null) {
            System.out.println("Nepoznati zahtjev!");
            //TODO dodati bolji nacin rjesavanja nastale situacije - odgovor moze biti neka stranica (Pogreska ...)
            return;
        }

        RequestDispatcher rd = this.getServletContext().getRequestDispatcher(odrediste);
        rd.forward(request, response);

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP
     * <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP
     * <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    /**
     *
     * metoda za dodavanje novog korisnika u bazu
     *
     * @param kor_ime korisnicko ime korisnika za dodavanje
     * @param ime ime korisnika za dodavanje
     * @param prezime - prezime korisnika za dodavanje
     * @param lozinka - lozijka korisnika za dodavanje
     * @param email_adresa - email adresa korisnika za dodavanje
     * @param PreparedStatement pst - služi za pripremanje podataka za
     * izvršavanje upita
     * @param String sql2 sel upit za dodavanje novog korisnika
     * @param pst.setString(indeks, varijabla) - služi za ubacivanje varijable
     * iz metode u upit
     * @throws DodajKorisnikaPogreska zbog preusmjeravanja na određeni jsp
     */
    public void dodajKorisnika(String kor_ime, String ime, String prezime, String lozinka, String email_adresa)
            throws DodajKorisnikaPogreska {

        String path = getServletContext().getRealPath("WEB-INF");
        String datoteka = path + java.io.File.separator + getServletContext().getInitParameter("konfiguracija");
        BP_Konfiguracija bp = new BP_Konfiguracija(datoteka);
        String connURL = bp.getServer_database() + bp.getUser_database();
        Connection conn = null;
        PreparedStatement pst = null;

        try {
            Class.forName(bp.getDriver_database());
        } catch (ClassNotFoundException ex) {
            System.out.println("Nisam se spojil na bazu" + ex.getMessage());
            throw new DodajKorisnikaPogreska("Greska kod spajanja na bazu");
        }

        String sql2 = "INSERT INTO polaznici"
                + "(kor_ime,ime,prezime,lozinka,email_adresa,vrsta)"
                + " VALUES "
                + "(?,?,?,?,?,'1')";
        if (bp.getStatus()) {
            try {
                conn = DriverManager.getConnection(connURL, bp.getUser_username(), bp.getUser_password());
                pst = conn.prepareStatement(sql2);
                pst.setString(1, kor_ime);
                pst.setString(2, ime);
                pst.setString(3, prezime);
                pst.setString(4, lozinka);
                pst.setString(5, email_adresa);
                int NumRowChanged = pst.executeUpdate();

                if (NumRowChanged != 1) {
                    throw new DodajKorisnikaPogreska();
                }

            } catch (SQLException ex) {
                System.out.println("Nisam se spojil na bazu2" + ex.getMessage());
                throw new DodajKorisnikaPogreska();
            } finally {
                try {
                    pst.close();
                } catch (SQLException ex) {
                    throw new DodajKorisnikaPogreska();
                }
                try {
                    conn.close();
                } catch (SQLException ex) {
                    throw new DodajKorisnikaPogreska();
                }
            }
        } else {
            throw new DodajKorisnikaPogreska();
        }
    }

    /**
     *
     * metoda za azuriranje korisnika
     *
     * @param kor_ime novo korisnicko ime
     * @param ime novo ime
     * @param prezime novo prezime
     * @param vrsta nova vrsta
     * @param PreparedStatement pst - služi za pripremanje podataka za
     * izvršavanje upita
     * @param String sql2 sel upit za dodavanje novog korisnika
     * @param pst.setString(indeks, varijabla) - služi za ubacivanje varijable
     * iz metode u upit
     * @throws AzuzirajKorisnikaPogreska
     */
    public void azurirajKorisnika(String kor_ime, String ime, String prezime, String vrsta)
            throws AzuzirajKorisnikaPogreska {
        String path = getServletContext().getRealPath("WEB-INF");
        String datoteka = path + java.io.File.separator + getServletContext().getInitParameter("konfiguracija");
        BP_Konfiguracija bp = new BP_Konfiguracija(datoteka);
        String connURL = bp.getServer_database() + bp.getUser_database();
        Connection conn = null;
        PreparedStatement pst = null;

        try {
            Class.forName(bp.getDriver_database());
        } catch (ClassNotFoundException ex) {
            System.out.println("Nisam se spojil na bazu" + ex.getMessage());
            throw new AzuzirajKorisnikaPogreska("Greska kod spajanja na bazu");
        }

        String sql2 = "UPDATE polaznici SET "
                + "ime=?,prezime=?,vrsta=? WHERE kor_ime=?";
        if (bp.getStatus()) {
            try {
                conn = DriverManager.getConnection(connURL, bp.getUser_username(), bp.getUser_password());
                pst = conn.prepareStatement(sql2);
                pst.setString(4, kor_ime);
                pst.setString(1, ime);
                pst.setString(2, prezime);
                pst.setString(3, vrsta);
                int NumRowChanged = pst.executeUpdate();

                if (NumRowChanged != 1) {
                    throw new AzuzirajKorisnikaPogreska();
                }

            } catch (SQLException ex) {
                System.out.println("Nisam se spojil na bazu2" + ex.getMessage());
                throw new AzuzirajKorisnikaPogreska();
            } finally {
                try {
                    pst.close();
                } catch (SQLException ex) {
                    throw new AzuzirajKorisnikaPogreska();
                }
                try {
                    conn.close();
                } catch (SQLException ex) {
                    throw new AzuzirajKorisnikaPogreska();
                }
            }
        } else {
            throw new AzuzirajKorisnikaPogreska();
        }

    }
}
