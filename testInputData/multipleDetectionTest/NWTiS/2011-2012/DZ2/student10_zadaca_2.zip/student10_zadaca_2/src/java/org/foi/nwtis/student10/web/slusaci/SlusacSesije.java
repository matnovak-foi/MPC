/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student10.web.slusaci;

import java.util.LinkedHashMap;
import java.util.Map;
import javax.servlet.http.HttpSessionAttributeListener;
import javax.servlet.http.HttpSessionBindingEvent;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

/**
 * Web application lifecycle listener.
 *
 * @author student10
 */
public class SlusacSesije implements HttpSessionListener, HttpSessionAttributeListener {

      
    /**
     * osluškuje kreiranje sesije i ispisuje na konzolu poruku kad je sesija kreirana
     * @param se 
     */
    
    
    @Override
    public void sessionCreated(HttpSessionEvent se) {
        System.out.println("Kreiraj sesiju: " + se.getSession().getId());
    }

    /**
     * osluškoje kad je sesija uništena i briše iz liste tog korisnika
     * @param se 
     */
    
    @Override
    public void sessionDestroyed(HttpSessionEvent se) {
        System.out.println("Obrisana sesija: " + se.getSession().getId());
        SlusacAplikacije.korisnici.remove(se.getSession().getId());
    }

    /**
     * osluškuje kad je atribut sesije dodan i dodaje taj atribut u Mapu korisnika
     * @param se 
     */
    
    @Override
    public void attributeAdded(HttpSessionBindingEvent se) {
        SlusacAplikacije.broj++;
        System.out.println("Sesija: " + se.getSession().getId() + " kreiran atribut: " + se.getName() + " vrij " + se.getValue());
        SlusacAplikacije.korisnici.put(se.getSession().getId(), se.getValue());
        se.getSession().getServletContext().setAttribute("popisKorisnika", SlusacAplikacije.korisnici);
        
    }

    /**
     * osluškoje kad je atribut sesije uništen i ispisuje poruku na konzolu
     * @param se 
     */
    
    @Override
    public void attributeRemoved(HttpSessionBindingEvent se) {
        System.out.println("Sesija: " + se.getSession().getId() + " obrisan atribut: " + se.getName());
    }

    /**
     * osluškoje kad je atribut sesije ažuriran i ispisuje poruku na konzolu
     * @param se 
     */
    
    @Override
    public void attributeReplaced(HttpSessionBindingEvent se) {
        System.out.println("Sesija: " + se.getSession().getId() + " promijenjen atribut: " + se.getName());
    }
}
