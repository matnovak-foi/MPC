/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student10.web;

/**
 *
 * @author student10
 * 
 *  ta klasa se aktivira ako se dogodi pogreska kod dodavanja korisnika
 * svaka pogreska kod dodavanja throws ovu klasu iznimke
 */
public class DodajKorisnikaPogreska extends Exception {

    /**
     * Creates a new instance of
     * <code>DodajKorisnikaPogreska</code> without detail message.
     */
    public DodajKorisnikaPogreska() {
    }

    /**
     * Constructs an instance of
     * <code>DodajKorisnikaPogreska</code> with the specified detail message.
     *
     * @param msg the detail message.
     */
    public DodajKorisnikaPogreska(String msg) {
        super(msg);
    }
}
