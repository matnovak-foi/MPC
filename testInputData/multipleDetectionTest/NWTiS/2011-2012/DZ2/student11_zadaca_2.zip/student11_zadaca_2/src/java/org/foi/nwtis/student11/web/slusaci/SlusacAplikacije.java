/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student11.web.slusaci;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import org.foi.nwtis.student11.konfiguracije.NemaKonfiguracije;
import org.foi.nwtis.student11.konfiguracije.bp.BP_Konfiguracija;

/**
 * Web application lifecycle listener.
 *
 * @author nwtis_3
 */
public class SlusacAplikacije implements ServletContextListener {

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        ServletContext sc = sce.getServletContext();
        String path = sc.getRealPath("WEB-INF");
        String datoteka = path + java.io.File.separator + sc.getInitParameter("konfiguracija");

        BP_Konfiguracija bp = null;
        try {
            bp = new BP_Konfiguracija(datoteka);
            sc.setAttribute("BP_Konfiguracija", bp);
        } catch (NemaKonfiguracije ex) {
            System.out.println("Nema konfiguracije!");
            return;
        }
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        System.out.println("Gasim kontekst: " + sce.getServletContext().getContextPath());
    }
}
