/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student11.web;

import java.io.*;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author nwtis_3
 */
public class Zapisnicar extends Thread {

    private File f;
    private String imeDatoteke;
    private DateFormat df;

    @Override
    public void interrupt() {
        super.interrupt();
    }

    @Override
    public void run() {
        while (true) {
            long time1 = System.currentTimeMillis();

            df = new SimpleDateFormat("_yyyyMMdd_HHmmss");
            imeDatoteke = PokretacZapisa.datoteka + df.format(new Date()) + ".txt";

            f = new File(PokretacZapisa.putanja + "zapisi\\");
            boolean isDirectoryCreated = f.mkdir();
            if (isDirectoryCreated) {
                System.out.println("Kreiran direktorij!");
            } else {
                System.out.println("Greška kod kreiranja direktorija!");
            }

            File f2 = new File(f.getPath() + "\\" + imeDatoteke);
            try {
                f2.createNewFile();
            } catch (IOException ex) {
                Logger.getLogger(Zapisnicar.class.getName()).log(Level.SEVERE, null, ex);
            }

            //zapisivanje u datoteku
            FileWriter fstream;
            try {
                fstream = new FileWriter(imeDatoteke);
                BufferedWriter out = new BufferedWriter(fstream);
                out.write("Hello Java");
            } catch (IOException ex) {
                Logger.getLogger(Zapisnicar.class.getName()).log(Level.SEVERE, null, ex);
            }


            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss.SSS dd.MM.yyyy");
            System.out.println("Sada je " + sdf.format(new Date()));
            try {
                //preuzimanje postavke interval i korigiranje vremena spavanja za utrošeno vrijeme rada
                int interval = PokretacZapisa.interval;
                long time2 = System.currentTimeMillis() - time1;
                sleep(interval - time2);
            } catch (InterruptedException ex) {
                break;
            }
        }
    }

    @Override
    public synchronized void start() {
        super.start();
    }
}
