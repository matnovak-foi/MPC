/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student11.web.slusaci;

import java.util.Collection;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpSessionAttributeListener;
import javax.servlet.http.HttpSessionBindingEvent;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;
import org.foi.nwtis.student11.web.kontrole.Korisnik;

/**
 * Web application lifecycle listener.
 *
 * @author student11
 */
public class SlusacSesije implements HttpSessionListener, HttpSessionAttributeListener {
    
    public static Collection<Korisnik> listaKorisnika;

    @Override
    public void sessionCreated(HttpSessionEvent se) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void sessionDestroyed(HttpSessionEvent se) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void attributeAdded(HttpSessionBindingEvent event) {
        listaKorisnika.add((Korisnik)event.getSession().getAttribute("korisnik"));
        event.getSession().setAttribute("popisKorisnika", listaKorisnika);
    }

    @Override
    public void attributeRemoved(HttpSessionBindingEvent event) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void attributeReplaced(HttpSessionBindingEvent event) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
