/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student11.web.kontrole;

/**
 *
 * @author student11
 */
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.annotation.WebServlet;
import org.foi.nwtis.student11.konfiguracije.bp.BP_Konfiguracija;
import org.foi.nwtis.student11.web.NeuspjesnaPrijava;

@WebServlet(name = "Login",
urlPatterns = {"/jsp/ProvjeraKorisnika"})

public class ProvjeraKorisnika extends HttpServlet {

    public void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException{
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
        HttpSession sesija = req.getSession();
        
        String idSesije = req.getSession().getId();
        String korisnik = req.getParameter("korisnickoIme");
        String lozinka = req.getParameter("password");

        ServletContext sc = getServletContext();
        BP_Konfiguracija bp = (BP_Konfiguracija) sc.getAttribute("BP_Konfiguracija");

        try {
            Class.forName(bp.getDriverDatabase());
        } catch (ClassNotFoundException ex) {
            out.println("Nema drivera!");
            return;
        }

        //spajanje na bazu
        java.sql.Connection conn = null;
        java.sql.Statement stmt = null;
        ResultSet rs = null;

        String url = bp.getServerDatabase() + bp.getUserDatabase();
        try {
            conn = DriverManager.getConnection(url, bp.getUserUsername(), bp.getUserPassword());
            stmt = conn.createStatement();
            String sql = "SELECT kor_ime, prezime, ime, vrsta FROM polaznici WHERE kor_ime = \"" + korisnik + "\" AND lozinka = " + lozinka;
            rs = stmt.executeQuery(sql);
            if (rs.next() == true) {
                Korisnik user = new Korisnik(rs.getString(1), rs.getString(2), rs.getString(3), idSesije, rs.getInt(4)); 
                
                sesija.setAttribute("korisnik", user);
                
                RequestDispatcher rd = getServletContext().getRequestDispatcher("/ProvjeraKorisnika");
                rd.forward(req, res);

            } else {
                try {
                        throw new NeuspjesnaPrijava();
                } catch (NeuspjesnaPrijava ex) {
                    Logger.getLogger(ProvjeraKorisnika.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
        } catch (SQLException ex) {
            out.println("SQL greska! <br/>");
            out.println("<a href=\"jsp\"index.jsp\">Pocetna stranica</a>");
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException ex) {
                }
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException ex) {
                }
            }
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException ex) {
                }
            }
        }
    }
}
