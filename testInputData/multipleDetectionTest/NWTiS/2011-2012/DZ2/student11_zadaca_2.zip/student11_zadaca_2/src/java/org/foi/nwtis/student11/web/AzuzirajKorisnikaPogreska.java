/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student11.web;

/**
 *
 * @author nwtis_3
 */
public class AzuzirajKorisnikaPogreska extends Exception {

    public AzuzirajKorisnikaPogreska() {
    }

    public AzuzirajKorisnikaPogreska(String msg) {
        super(msg);
    }
}
