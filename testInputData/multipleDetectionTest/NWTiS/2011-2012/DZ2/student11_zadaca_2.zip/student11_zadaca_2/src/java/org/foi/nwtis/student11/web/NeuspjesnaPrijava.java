/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student11.web;

/**
 *
 * @author nwtis_3
 */
public class NeuspjesnaPrijava extends Exception{
    public NeuspjesnaPrijava() {

    }
    
    public NeuspjesnaPrijava(String msg) {
        super(msg);
    }
}
