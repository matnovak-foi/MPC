/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student11.web;

/**
 *
 * @author nwtis_3
 */
public class DodajKorisnikaPogreska extends Exception {

    public DodajKorisnikaPogreska() {
    }

    public DodajKorisnikaPogreska(String msg) {
        super(msg);
    }
}
