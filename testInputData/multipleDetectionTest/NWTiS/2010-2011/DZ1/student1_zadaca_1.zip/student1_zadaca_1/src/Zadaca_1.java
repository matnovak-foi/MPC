/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.File;
import java.util.Date;
import java.util.Timer;
import org.foi.nwtis.dkermek.konfiguracije.Konfiguracija;
import org.foi.nwtis.dkermek.konfiguracije.KonfiguracijaApstraktna;
import org.foi.nwtis.student1.zadaca_1.Dnevnik;
import org.foi.nwtis.student1.zadaca_1.Dretva_1;
import org.foi.nwtis.student1.zadaca_1.Dretva_2;
import org.foi.nwtis.student1.zadaca_1.Dretva_3;


/**
 * Prva zadaca iz kolegija NWTiS-a
 * Utroseno vremena: ~10h
 *
 * @author student3Name
 */
public class Zadaca_1 {

    /**
     * @param args the command line arguments Ime konfiguracijske datoteke
     */
    public static void main(String[] args) {
        if (args.length != 1) {
            System.out.println("Nije upisano 1 argument");
            return;
        }
        String naziv = args[0];

        File datoteka = new File(naziv);
        Konfiguracija konfig = KonfiguracijaApstraktna.Konfiguracija(naziv);

        if (datoteka.exists()) {
            konfig.ucitajKonfiguraciju(naziv);
        }

        int brojDretvi = Integer.parseInt(konfig.dajPostavku("brojDretvi"));
        String dnevnikDatoteka = konfig.dajPostavku("dnevnik");
        int interval_1 = Integer.parseInt(konfig.dajPostavku("interval_1"));
        String vrijemePocetka = konfig.dajPostavku("vrijemePocetka");
        int interval_3 = Integer.parseInt(konfig.dajPostavku("interval_3"));
        String datotekaKraj = konfig.dajPostavku("datotekaKraj");

        Dnevnik dnevnik = Dnevnik.getInstance();
        dnevnik.setNazivDatoteke(dnevnikDatoteka);
        dnevnik.upisi("pocetak upisivanja");

        Dretva_1 dretve_1[] = new Dretva_1[brojDretvi];
        for (int i = 0; i < brojDretvi; i++) {
            String izvor = konfig.dajPostavku("URL_" + (i+1));
            dretve_1[i] = new Dretva_1(i, interval_1, izvor, dnevnik);
            dretve_1[i].start();

        }
        Dretva_2 dretva_2 = new Dretva_2(vrijemePocetka, dnevnik);
        dretva_2.start();

        Timer timer = new Timer();
        Dretva_3 dretva_3 = new Dretva_3(datotekaKraj, dretve_1, dretva_2, timer);
        timer.scheduleAtFixedRate(dretva_3, new Date(), interval_3*1000);

    }
}
