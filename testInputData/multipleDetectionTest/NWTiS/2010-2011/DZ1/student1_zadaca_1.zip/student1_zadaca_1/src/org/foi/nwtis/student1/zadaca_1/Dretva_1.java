/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student1.zadaca_1;

import java.net.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Provjerava definirani sadrzaj i biljezi vrijeme svake promjenu
 *
 * @author student3Name
 */
public class Dretva_1 extends Thread {

    private int broj;
    private int interval;
    private String izvor;
    private Dnevnik dnevnik;
    private int velicinaSadrzaja;

    public Dretva_1(int broj, int interval, String izvor, Dnevnik dnevnik) {
        super("nwtis => dretva_1 broj: " + (broj+1));
        this.broj = broj;
        this.interval = interval;
        this.izvor = izvor;
        this.dnevnik = dnevnik;
        this.velicinaSadrzaja = 0;
        System.out.println("Dretva " + (broj+1) + " inicijalizirana.");
    }

    @Override
    public void run() {
        SimpleDateFormat formatter = new SimpleDateFormat ("yyyy.MM.dd HH.mm.ss");
        Date currentTime_1 = new Date();
        String dateString = formatter.format(currentTime_1);

        System.out.println(this.getName()+ " pokrenuta");
        int iteracija = 0;
        while(true){
            try {
                iteracija++;
                System.out.println(this.getName() + " izvodi iteraciju " + iteracija);

                URL u = new URL(this.izvor);
                InputStream in = u.openStream();
                in = new BufferedInputStream(in);
                Reader r = new InputStreamReader(in);
                int c;
                int temp=0;
                while ((c = r.read()) != -1) {
                    temp++;
                }
                if (velicinaSadrzaja != temp){
                    velicinaSadrzaja = temp;
                    dnevnik.upisi(this.getName() + ": " + dateString+" sadrzaj promjenjen");
                }

                sleep(interval * 100);
            } catch (MalformedURLException ex) {
                Logger.getLogger(Dretva_1.class.getName()).log(Level.SEVERE, null, ex);
            }catch (IOException ex){
                Logger.getLogger(Dretva_1.class.getName()).log(Level.SEVERE, null, ex);
            } catch (InterruptedException ex) {
                System.out.println(this.getName()+ " prekinuta");
                //Dnevnik dnevnik = Dnevnik.getInstance();
                dnevnik.upisi(this.getName() + ": " + dateString+" dretva prekinuta");
                break;
            }
        }

    }
}
