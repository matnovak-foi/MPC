/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student1.zadaca_1;

import java.io.File;
import java.util.Timer;
import java.util.TimerTask;

/**
 *
 * @author student3Name
 */
public class Dretva_3 extends TimerTask {

    private String datotekaKraj;
    private Dretva_1[] dretve_1;
    private Dretva_2 dretve_2;
    private Timer timer;

    public Dretva_3(String datotekaKraj, Dretva_1[] dretve_1, Dretva_2 dretve_2, Timer timer) {
        this.dretve_1 = dretve_1;
        this.dretve_2 = dretve_2;
        this.datotekaKraj = datotekaKraj;
        this.timer = timer;
    }

    @Override
    public void run() {
        System.out.println("Dretva_3 pokrenuta");

        File datoteka = new File(datotekaKraj);
        if (!datoteka.exists()) {
            System.out.println("Dretva 3 => Nema datoteke, nastavljam s radom!");
        } else {
            System.out.println("Dretva 3 => Pronadena datoteka, zaustavljam sve dretve!");
            for (Dretva_1 d : dretve_1) {
                System.out.println("Dretva 3 => Zaustavljam dretvu: " + d.getName());
                d.interrupt();
            }
            System.out.println("Dretva 3 => Zaustavljam dretvu: " + dretve_2.getName());
            dretve_2.interrupt();
            timer.cancel();


        }
    }
}
