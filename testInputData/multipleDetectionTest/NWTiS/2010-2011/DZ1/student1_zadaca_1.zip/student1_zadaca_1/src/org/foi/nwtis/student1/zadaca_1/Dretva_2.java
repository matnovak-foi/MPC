/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student1.zadaca_1;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * u zadano vrijeme (u knofiguracijskoj dat.) postavlja naziv datoteke Dnevnika
 * i time se za novi dan kreira nova datoteka
 * pokrece se svaki dan u isto vrijeme za vrijeme izvrsavanja aplikacije
 *
 * @author student3Name
 */
public class Dretva_2 extends Thread {

    private String vrijemePocetka;
    private Dnevnik dnevnik;

    public Dretva_2(String vrijemePocetka, Dnevnik dnevnik) {
        super("nwtis => dretva_2 ");
        this.vrijemePocetka = vrijemePocetka;
        this.dnevnik = dnevnik;
    }

    @Override
    public void run() {
        System.out.println(this.getName() + " pokrenuta");
        int iteracija = 0;
        int interval = 24*60*60*1000;
        Date sada = new Date();
        Date pocetak = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat ("yyyy.MM.dd HH:mm:ss");
        SimpleDateFormat formatter2 = new SimpleDateFormat ("yyyy.MM.dd ");
        try {
            pocetak = (Date)formatter.parse(formatter2.format(sada) + vrijemePocetka);
            sada = (Date)formatter.parse(formatter.format(sada));
            long diff = 0;
            if (pocetak.getTime() > sada.getTime()){
                diff = pocetak.getTime() - sada.getTime();
            }else{
                diff = interval - (sada.getTime() - pocetak.getTime());
            }
            System.out.println(this.getName() + " Spava " + diff + " milisekundi");
            sleep(diff);
        } catch (ParseException ex) {
            System.out.println(this.getName() + " pocetno vrijeme nije u pravilnom formatu!");
        } catch (InterruptedException ex) {
                System.out.println(this.getName() + " prekinuta");
        }
        
        while (true) {
            try {
                System.out.println(this.getName() + " izvodi iteraciju " + iteracija);
                dnevnik.noviNazivDatoteke();
                sleep(interval);
            } catch (InterruptedException ex) {
                System.out.println(this.getName() + " prekinuta");
                break;
            }
        }

    }
}
