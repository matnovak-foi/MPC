/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.foi.nwtis.student1.zadaca_1;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;
/**
 *
 * @author student3Name
 *
 * klasa Dnevnik sluzi za bilježenje promjena sadrzaja na pracenom sadrzaju
 * promjene se biljeze u datoteku definiranu Stringom nazivDatotekePar
 */
public class Dnevnik {

    private String nazivDatoteke;
    private String nazivDatotekePar;

    private Dnevnik() {
    }

    public static Dnevnik getInstance() {
        return DnevnikHolder.INSTANCE;
    }

    private static class DnevnikHolder {
        private static final Dnevnik INSTANCE = new Dnevnik();
    }

    public String getNazivDatoteke() {
        return nazivDatoteke;
    }

    /**
     * Poziva se pri inicijalizaciji dnevnika i postavlja ime datoteke u koju se zapisuju bilješke
     *
     * @param nazivDatoteke naziv datoteke dnevnika iz konfiguracijske datoteke
     */
    public void setNazivDatoteke(String nazivDatoteke) {
        this.nazivDatotekePar = nazivDatoteke;
        noviNazivDatoteke();
    }

    /**
     * Koristi se za postavljanje datoteke dnevnika ovisno o trenutnom datumu
     * poziva se iz prilikom inicijalizacije i poziva ju dretva_2
     */
    public void noviNazivDatoteke(){
        SimpleDateFormat formatter = new SimpleDateFormat (".yyyy_MM_dd");
        Date currentTime_1 = new Date();
        String dateString = formatter.format(currentTime_1);
        this.nazivDatoteke = nazivDatotekePar + dateString + ".log";
    }

    /**
     * Upisuje u dnevnik poruku definiranu u parametru
     *
     * @param poruka
     */
    public synchronized void upisi(String poruka){
        try {
            FileWriter out = new FileWriter(nazivDatoteke, true);
            out.write(poruka+System.getProperty("line.separator"));
            //System.out.println("Upisano u dnevnik!");
            out.close();
        }catch (IOException ex){
            System.out.println("Nije moguce upisivati u dnevnik!");
        }
    }
 }
