package org.foi.nwtis.student2.zadaca_1;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Klasa za prvu dretvu koja provjerava veličinu sadržaja izvora podatka
 * @author za dnevnik koja služi
 */
public class Dretva_1 extends Thread{
    private int brojDretve;
    private int interval;
    private String izvorPodataka;
    private Dnevnik dnevnik;
    private String prvaDatoteka;

    /**
     * Konstruktor dretve koji služi za analizu
     * sadržaja sa određenog web mjesta
     *
     * @param brojDretve redni broj dretve
     * @param interval interval u sekundama
     * @param izvorPodataka web mjesto izvora podataka
     * @param dnevnik objekt dnevnik
     */
    public Dretva_1(int brojDretve, int interval, String izvorPodataka, Dnevnik dnevnik) {

        super("NWTiS => student2 =>"+brojDretve);
        this.brojDretve=brojDretve;
        this.interval=interval;
        this.izvorPodataka=izvorPodataka;
        this.dnevnik=dnevnik;
        this.prvaDatoteka="";
    }

    /**
     * Intervalno izvršavanje dretve prema zadanom intervalu
     */
    @Override
    public void run() {

        int iteracija=0;
        System.out.println(this.getName()+". dretva se izvršava");
        
        while(true){
            System.out.println(this.getName()+". dretva izvršava ciklus: "+iteracija++);
            
            SimpleDateFormat f1=new SimpleDateFormat("MM_dd_HH_mm_ss");
            f1.set2DigitYearStart(new Date());
            Calendar cal1=f1.getCalendar();
            long startTime=cal1.getTimeInMillis();

            try{
                try {
                    // Utvrđivanje veličine izvora podataka, provjeravanje veličine u odnosu na prethodni ciklus i zapis u dnevnik
                    URL u = new URL(this.izvorPodataka);
                    try {
                        if (u.openConnection().getContentType() != null) {
                            InputStream in;
                            try {
                                in = u.openStream();
                                in = new BufferedInputStream(in);
                                Reader r = new InputStreamReader(in);

                                SimpleDateFormat f=new SimpleDateFormat("yyyy.MM.dd hh.mm.ss");
                                f.set2DigitYearStart(new Date());
                                Calendar calendar=f.getCalendar();
                                String datum=f.format(calendar.getTime());

                                //Zapisivanje sadržaja web mjesta u datoteku
                                int zn;
                                String ime_datoteke=this.brojDretve+"_"+datum+"_temp.txt";
                                FileWriter datoteka = new FileWriter(ime_datoteke);
                                BufferedWriter buff = new BufferedWriter(datoteka);

                                while ((zn = r.read()) != -1) {
                                    buff.write(zn);
                                }
                                buff.close();
                                

                                //Uspoređivanje druge spremljene datoteke sa prvom spremljenom datotekom
                                File datoteka1=null;
                                File datoteka2=null;

                                if(this.prvaDatoteka==""){
                                    this.dnevnik.upisiPoruku("Pohranjujem trenutno stanje web mjesta");

                                }else{
                                    String naziv1 = this.prvaDatoteka;
                                    datoteka1 = new File(naziv1);
                                    String naziv2 = ime_datoteke;
                                    datoteka2 = new File(naziv2);
                                    boolean b=fpromjena(datoteka1,datoteka2);

                                    if(b==true){
                                        this.dnevnik.upisiPoruku("Dretva_1 "+this.brojDretve+","+datum+", Status: "+"Promjena na web mjestu: "+this.izvorPodataka);

                                    }else{
                                        this.dnevnik.upisiPoruku("Dretva_1 "+this.brojDretve+","+datum+", Status: "+"Nema promjene na web mjestu: "+this.izvorPodataka);
                                    }
                                }

                                //Brisanje stare datoteke nakon provjere
                                if(datoteka1!=null) {
                                    boolean del=datoteka1.delete();
                                }

                                //Postavljanje prije spremljene datoteke kao stare
                                this.prvaDatoteka=ime_datoteke;

                            } catch (IOException ex) {
                                Logger.getLogger(Dretva_1.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }
                    } catch (IOException ex) {
                        Logger.getLogger(Dretva_1.class.getName()).log(Level.SEVERE, null, ex);
                    }

                } catch (MalformedURLException ex) {
                    Logger.getLogger(Dretva_1.class.getName()).log(Level.SEVERE, null, ex);
                }

                // Utvrđivanje vremena korekcije intervala
                SimpleDateFormat format2=new SimpleDateFormat("MM_dd_HH_mm_ss");
                format2.set2DigitYearStart(new Date());
                Calendar calendar2=format2.getCalendar();
                long endTime=calendar2.getTimeInMillis();

                long razlika=endTime-startTime;
                long sleep_in_millis=interval*1000-razlika;
                sleep(sleep_in_millis);

            }catch(InterruptedException ex){
                // Ispis da se dogodio prekid
                System.out.println("Prekid u dretvi_1");
                break;
            }
        }
    }

    /**
     * Pokretanje dretve
     */
    @Override
    public synchronized void start() {
        super.start();
    }

    /**
   * Funkcija koja provjerava da li je prva datoteka iste veličine kao i druga
   *
   * @param prva datoteka za usporedbu
   * @param druga datoteka za usporedbu
   * @return vraća rezultat provjere
   */
      private boolean fpromjena(File stari, File novi) {
        boolean pr = false;
        try {
          //Uspoređivanje zadnje skinutog filea s prvim
          BufferedReader b1 = new BufferedReader(new FileReader(stari));
          BufferedReader b2 = new BufferedReader(new FileReader(novi));

          String line1, line2;
          try {
            while ((line1 = b1.readLine()) != null) {
              line2 = b2.readLine();
              if (line2 == null) {
                System.out.println("Još ništa za usporedbu, čekajte slijedeći ciklus.");
              } else if (!line1.equals(line2)) {
                pr = true;
              }
            }
          } catch (IOException ex) {
            Logger.getLogger(Dretva_1.class.getName()).log(Level.SEVERE, null, ex);
          }

        } catch (FileNotFoundException ex) {
          Logger.getLogger(Dretva_1.class.getName()).log(Level.SEVERE, null, ex);
        }

        return pr;
      }
    }


