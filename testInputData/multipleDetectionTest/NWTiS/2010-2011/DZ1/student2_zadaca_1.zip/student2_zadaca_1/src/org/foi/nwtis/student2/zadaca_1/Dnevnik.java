package org.foi.nwtis.student2.zadaca_1;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;

/**
 *
 * @author student2Name
 */
public class Dnevnik {
    private String nazivDatoteke;

    /**
     * Metoda za dnevnik koja služi vraćanju zadanog naziva dnevnika
     * @return vraća naziv dnevnika
     */
    public String getImeDatoteke() {
        return nazivDatoteke;
    }

    /**
     * Metoda za dnevnik koja služi postavljanju novog naziva datoteke dnevnika
     *
     * @param nazivDatoteke novi naziv datoteke dnevnika
     */
    public void setImeDatoteke(String nazivDatoteke) {
        this.nazivDatoteke = nazivDatoteke;
    }
    private Dnevnik(){

    }

    public static Dnevnik getInstance(){
        return DnevnikHolder.Instance;
    }
    
    public static class DnevnikHolder{
        private static final Dnevnik Instance=new Dnevnik();
    }

    /**
     * Metoda za dnevnik koja služi upisu zadanog teksta u datoteku dnevnika
     *
     * @param tekst sadržaj koji želimo upisati
     * @throws IOException
     */
    public synchronized void upisiPoruku(String tekst) throws IOException{
        // Upisivanje u dnevnik
        FileWriter log = new FileWriter(this.nazivDatoteke, true);
        BufferedWriter unos_buffer = new BufferedWriter(log);
        Date vrijeme = new Date();

        unos_buffer.write(tekst);
        unos_buffer.newLine();
        unos_buffer.close();
    }
}
