package org.foi.nwtis.student2.zadaca_1;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Klasa za treću dretvu koja služi za zaustavljanje 
 * svih dretvi programa ako je pronađena posebna datoteka
 * @author student2Name
 */
public class Dretva_3 extends TimerTask {
    private String datotekaKraj;
    private Dretva_1 dretve_1[];
    private Dretva_2 dretva_2;
    private Dnevnik dnevnik;
    private Timer timer;

    /**
     * Konstruktor za treću dretvu koja služi za zaustavljanje
     * svih dretvi programa ako je pronađena posebna datoteka
     *
     * @param datotekaKraj naziv datoteke čije postojanje signalizira dretvi da treba terminirati sve dretve
     * @param dretve_1 polje dretvi za analizu sadržaja sa zadanog web mjesta
     * @param dretva_2 dretva za kreiranje dnevnika
     * @param dnevnik objekt dnevnika
     * @param timer koji služi za pokretanje ove dretve
     */
    public Dretva_3(String datotekaKraj, Dretva_1 dretve_1[], Dretva_2 dretva_2, Dnevnik dnevnik, Timer timer) {
        this.datotekaKraj = datotekaKraj;
        this.dretve_1 = dretve_1;
        this.dretva_2 = dretva_2;
        this.dnevnik = dnevnik;
        this.timer = timer;
    }

    /**
     * Izvršavanje dretve koja služi za zaustavljanje svih dretvi programa
     */
    @Override
    public void run() {
        System.out.println("Dretva_3 pokrenuta");

        //Provjera da li postoji datotekaKraj
        File datoteka = new File(datotekaKraj);
        if (!datoteka.exists()) {
            System.out.println("Ne postoji zadana datoteka, nista ne brisem");
            return;
        } else {
            System.out.println("Postoji zadana datoteka, prekidam dretve");

            //Prekidanje svih 1. dretvi
            for(Dretva_1 d : dretve_1) {
                System.out.println("Prekidam " + d.getName());
                d.interrupt();
                try {
                    
                    //Postavlja vrijednost datuma na trenutni sistemski datum
                    SimpleDateFormat format_datuma=new SimpleDateFormat("hh:mm:ss");
                    format_datuma.set2DigitYearStart(new Date());
                    Calendar calendar=format_datuma.getCalendar();
                    String vrijeme=format_datuma.format(calendar.getTime());

                    //Pisanje u dnevnik
                    this.dnevnik.upisiPoruku("Prekidam dretvu_1 :" + d.getName()+", vrijeme prekida: "+vrijeme);
                } catch (IOException ex) {
                    Logger.getLogger(Dretva_3.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            System.out.println("Prekidam dretvu_2, vrijeme prekida: ");
            
            //prekidanje druge dretve
            try {

                //Postavlja vrijednost datuma na trenutni sistemski datum
                SimpleDateFormat format_datuma=new SimpleDateFormat("hh:mm:ss");
                format_datuma.set2DigitYearStart(new Date());
                Calendar calendar=format_datuma.getCalendar();
                String vrijeme=format_datuma.format(calendar.getTime());

                //Pisanje u dnevnik
                this.dnevnik.upisiPoruku("Prekidam dretvu_2, vrijeme prekida: "+vrijeme);
                dretva_2.interrupt();
            } catch (IOException ex) {
                Logger.getLogger(Dretva_3.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            //prekidanje treće dretve
            try {

                //Postavlja vrijednost datuma na trenutni sistemski datum
                SimpleDateFormat format_datuma=new SimpleDateFormat("hh:mm:ss");
                format_datuma.set2DigitYearStart(new Date());
                Calendar calendar=format_datuma.getCalendar();
                String vrijeme=format_datuma.format(calendar.getTime());

                //Pisanje u dnevnik
                this.dnevnik.upisiPoruku("Prekidam dretvu_3, vrijeme prekida: "+vrijeme);
                timer.cancel();
            } catch (IOException ex) {
                Logger.getLogger(Dretva_3.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
    }
}