package org.foi.nwtis.student2.zadaca_1;
import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Klasa za drugu dretvu koja kreira novo ime dnevnika
 * @author student2Name
 */
public class Dretva_2 extends Thread{
    private String vrijemePocetka;
    private Dnevnik dnevnik;
    private String dnevnikNaziv;

    /**
     * Konstruktor dretve za kreiranje novog dnevnika
     *
     * @param vrijemePocetka vrijeme pokretanja dretve
     * @param dnevnik objekt dnevnika
     * @param dnevnikNaziv zadana ekstenzija za naziv datoteke dnevnika
     */
    public Dretva_2(String vrijemePocetka, Dnevnik dnevnik, String dnevnikNaziv) {
        super("NWTiS => student2 => Dnevnik promjena imena.");
        this.vrijemePocetka=vrijemePocetka;
        this.dnevnik=dnevnik;
        this.dnevnikNaziv=dnevnikNaziv;
    }

    /**
     * Izvršavanje dretve za kreiranje novog dnevnika
     */
    @Override
    public void run() {
        int iteracija=0;
        System.out.println(this.getName()+" dretva se izvršava");
        while(true){
            System.out.println(this.getName()+" dretva izvršava ciklus: "+iteracija++);

            // Utvrđivanje trenutnog vremena i razlike do vremena početka
            GregorianCalendar gkal = new GregorianCalendar();
            Date dat=gkal.getTime();
            long vrijeme1=dat.getTime();

            SimpleDateFormat format=new SimpleDateFormat("hh:mm:ss");
            try {
                format.parse(this.vrijemePocetka);
            } catch (ParseException ex) {
                Logger.getLogger(Dretva_2.class.getName()).log(Level.SEVERE, null, ex);
            }
            //Postavljanje datuma u calendaru2 na ono koje je postavljeno u calendaru1
            GregorianCalendar gkal2=(GregorianCalendar) format.getCalendar();
            gkal2.set(GregorianCalendar.YEAR, gkal.get(GregorianCalendar.YEAR));
            gkal2.set(GregorianCalendar.MONTH, gkal.get(GregorianCalendar.MONTH));
            gkal2.set(GregorianCalendar.DAY_OF_MONTH, gkal.get(GregorianCalendar.DAY_OF_MONTH));

            if(gkal2.compareTo(gkal)<0){
                gkal2.add(GregorianCalendar.DAY_OF_MONTH,1);
            }
            Date datum2 = gkal2.getTime();
            long vrijeme2=datum2.getTime();




            //Izračun razlike trenutnog vremena i vremena početka (u milisekundama)
            long razlika_u_vremenu=vrijeme2-vrijeme1;

            try {
                sleep(razlika_u_vremenu);
            } catch (InterruptedException ex) {
                Logger.getLogger(Dretva_2.class.getName()).log(Level.SEVERE, null, ex);
                System.out.println("Prekid u dretvi_2");
                break;
            }

            
            SimpleDateFormat format_datuma=new SimpleDateFormat("yyyy_MM_dd");
            //Metoda koja postavlja vrijednost datuma na trenutni sistemski datum
            format_datuma.set2DigitYearStart(new Date());
            Calendar calendar=format_datuma.getCalendar();
            String datum=format_datuma.format(calendar.getTime());

            //Zadavanje novog naziva dnevnika
            String naziv =this.dnevnikNaziv+"."+datum+".log";
            this.dnevnik.setImeDatoteke(naziv);

            //Kreiranje datoteke za novi dnevnik
            File datoteka = new File(naziv);
            try {
                boolean b = datoteka.createNewFile();
            } catch (IOException ex) {
                Logger.getLogger(Dretva_2.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    /**
     * Pokretanje dretve
     */
    @Override
    public synchronized void start() {
        super.start();
    }
}
