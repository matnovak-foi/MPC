/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.foi.nwtis.student3.zadaca_1;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

/**
 * Klasa za upravljanje dnevnikom
 * @author student3Name
 */
public class Dnevnik {
    private String nazivDatoteke;

    /**
     * Konstruktor
     * @author student3Name
     */
    private Dnevnik() {
    }

    /**
     * @author student3Name
     * @return instanca klase Dnevnik
     */
    public static Dnevnik getInstance() {
        return DnevnikHolder.INSTANCE;
    }

    /**
     * Instanciranje signleton klase
     * @author student3Name
     */
    private static class DnevnikHolder {
        private static final Dnevnik INSTANCE = new Dnevnik();
    }

    /**
     * Geter za dohvaćanje imena datoteke dnevnika
     * @author student3Name
     */
    public String getNazivDatoteke() {
        return nazivDatoteke;
    }

    /**
     * Seter za postavljanje imena datoteke dnevnika
     * @author student3Name
     * @param nazivDatoteke naziv datoteke
     */
    public void setNazivDatoteke(String nazivDatoteke) {
        this.nazivDatoteke = nazivDatoteke;
    }

    /**
     * Metoda za upisivanje u datoteku dnevnika
     * @author student3Name
     * @param poruka tekst poruke koja se upisuje u datoteku
     * @throws IOException
     */
    public synchronized void upisi(String poruka) throws IOException{
        FileWriter outputFile = new FileWriter(nazivDatoteke, true);
        BufferedWriter out = new BufferedWriter(outputFile);
        out.write(poruka);
        out.newLine();
        out.close();
    }
 }
