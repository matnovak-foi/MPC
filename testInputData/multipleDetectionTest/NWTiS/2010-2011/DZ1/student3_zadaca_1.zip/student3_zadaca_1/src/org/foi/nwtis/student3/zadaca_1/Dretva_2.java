package org.foi.nwtis.student3.zadaca_1;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Klasa Dretva 2
 * @author student3Name
 */
public class Dretva_2 extends Thread{
    private String vrijemePocetka;
    private Dnevnik dnevnik;

    /**
     * Konstruktor
     * @author student3Name
     * @param vrijemePocetka vrijeme pocetka dretve
     * @param dnevnik instanca klase dnevnik
     */
    public Dretva_2(String vrijemePocetka, Dnevnik dnevnik) {
        super("org.foi.nwtis.student3.dretva_2");
        this.vrijemePocetka = vrijemePocetka;
        this.dnevnik = dnevnik;
    }

    /**
     * Metoda run
     * @author student3Name
     */
    @Override
    public void run() {
        System.out.println(this.getName() + " pokrenuta");
        int iteracija=0;
        int interval= 24*60*60*1000; //1 dan
        while(true){
            try {
                System.out.println(this.getName()+ " izvodi iteraciju :" +iteracija++);

                String nazivDatoteke = dnevnik.getNazivDatoteke();
                SimpleDateFormat datumDnevnik = new SimpleDateFormat("yyyy_MM_dd");
                nazivDatoteke = nazivDatoteke.substring(0, nazivDatoteke.length()-14);
                nazivDatoteke += datumDnevnik.format(new Date())+".log";
                dnevnik.setNazivDatoteke(nazivDatoteke);

                SimpleDateFormat datum = new SimpleDateFormat("yyyy:MM:dd");
                SimpleDateFormat datumvrijeme = new SimpleDateFormat("yyyy:MM:dd HH:mm:ss");

                Date vrijemeSada = new Date();
                Date vrijemePocetak = datumvrijeme.parse(datum.format(vrijemeSada)+" "+vrijemePocetka);
                long razlika = vrijemePocetak.getTime()-vrijemeSada.getTime();
                if(razlika < 0){
                    razlika += interval;
                }

                sleep(razlika);
            } catch (ParseException ex) {
                System.out.println(ex.toString());
            } catch (InterruptedException e) {
                System.out.println(this.getName()+ " prekinuta");
                Date date = new Date();
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy.MM.dd HH.mm.ss");
                try {
                    dnevnik.upisi(dateFormat.format(date) + " " + this.getName() + " prekinuta");
                } catch (IOException ex) {
                    System.out.println(ex.toString());
                }
                break;
            }
        }
    }

}
