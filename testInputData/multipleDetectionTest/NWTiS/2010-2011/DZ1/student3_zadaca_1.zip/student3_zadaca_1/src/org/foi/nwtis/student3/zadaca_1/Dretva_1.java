package org.foi.nwtis.student3.zadaca_1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Klasa Dretva 1
 * @author student3Name
 */
public class Dretva_1 extends Thread{
    private int broj;
    private  int interval;
    private String izvor;
    private Dnevnik dnevnik;

    /**
     * Konstruktor
     * @author student3Name
     * @param broj redni broj dretve
     * @param interval interval pokretanja dretve
     * @param izvor url
     * @param dnevnik instanca klase dnevnik
     */
    public Dretva_1(int broj, int interval, String izvor, Dnevnik dnevnik) {
        super("org.foi.nwtis.student3.dretva_1_" + broj);
        this.broj = broj;
        this.interval = interval;
        this.izvor = izvor;
        this.dnevnik = dnevnik;
        System.out.println("Dretva " + broj + " incijalizirana");
    }

    /**
     * Metoda run
     * @author student3Name
     */
    @Override
    public void run() {
        System.out.println(this.getName() + " pokrenuta");
        int iteracija=0;
        Date date = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy.MM.dd HH.mm.ss");
        URL u;
        InputStream is;
        BufferedReader d;
        String l = "";

        String sadrzaj1 = "";
        String sadrzaj2 = "";

        while(true){
            try {
                long pocetak = System.currentTimeMillis();
                System.out.println(this.getName()+ " izvodi iteraciju :" +iteracija++);

                try{
                    u = new URL(izvor);
                    is = u.openStream();
                    d = new BufferedReader(new InputStreamReader(is));

                    while ((l = d.readLine()) != null) {
                        sadrzaj2 += l;
                    }

                    if (sadrzaj2.length()==sadrzaj1.length()) {
                        dnevnik.upisi(dateFormat.format(date) +" "+ this.getName() + " Status: NEMA PROMJENE");
                    } else {
                        if(iteracija == 1) {
                            dnevnik.upisi(dateFormat.format(date) +" "+ this.getName() + " Status: PRVO DOHVACANJE");
                        } else {
                            dnevnik.upisi(dateFormat.format(date) +" "+ this.getName() + " Status: PROMJENA");
                        }
                    }

                    sadrzaj1 = sadrzaj2;
                    sadrzaj2 = "";
                    d.close();
                    is.close();
                } catch (Exception e) {
                    try {
                        dnevnik.upisi(dateFormat.format(date) +" "+ this.getName() + " Status: GRESKA KOD DOHVACANJA");
                    } catch (IOException ex) {
                        System.out.println(ex.toString());
                    }
                }

                long kraj = System.currentTimeMillis();
                sleep((interval * 1000)-(kraj-pocetak));
            } catch (InterruptedException e) {
                System.out.println(this.getName()+ " prekinuta");
                try {
                    dnevnik.upisi(dateFormat.format(date) +" "+ this.getName() + " prekinuta");
                } catch (IOException ex) {
                    System.out.println(ex.toString());
                }
                break;
            }
        }
    }
}
