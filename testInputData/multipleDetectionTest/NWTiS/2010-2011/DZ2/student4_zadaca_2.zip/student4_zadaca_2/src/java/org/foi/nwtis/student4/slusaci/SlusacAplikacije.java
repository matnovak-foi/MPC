/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.foi.nwtis.student4.slusaci;

import java.io.File;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import org.foi.nwtis.student4.konfiguracije.bp.BP_Konfiguracija;

/**
 * Web application lifecycle listener.
 * @author student4
 */
public class SlusacAplikacije implements ServletContextListener {

    public void contextInitialized(ServletContextEvent sce) {
        String nazivDatoteke = sce.getServletContext().getRealPath("WEB-INF") + File.separator
                    + sce.getServletContext().getInitParameter("konfiguracija");
            File datoteka = new File(nazivDatoteke);

            BP_Konfiguracija bpKonfig = new BP_Konfiguracija(nazivDatoteke);

            sce.getServletContext().setAttribute("BP_Konfiguracija", bpKonfig);

            System.out.println("Kontekst: " + sce.getServletContext().getContextPath() + " je inicijalizran.");

            String serverDatabase =((BP_Konfiguracija) sce.getServletContext().getAttribute("BP_Konfiguracija")).getPosluziteljBazePodataka();

            System.out.println("Server database: " + serverDatabase );
    }

    public void contextDestroyed(ServletContextEvent sce) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
