/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.foi.nwtis.student4.slusaci;

import javax.servlet.http.HttpSessionAttributeListener;
import javax.servlet.http.HttpSessionBindingEvent;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;
import org.foi.nwtis.student4.web.kontrole.Korisnik;

/**
 * Web application lifecycle listener.
 * @author student4
 */
public class SlusacSesije implements HttpSessionListener, HttpSessionAttributeListener {

    public void sessionCreated(HttpSessionEvent se) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void sessionDestroyed(HttpSessionEvent se) {
        throw new UnsupportedOperationException("Not supported yet.");
        // TODO obrisati korisnika iz popisa korisnika ako je aktivan. Ideja potrazi korisnika koji ima broj sesije.
    }

    public void attributeAdded(HttpSessionBindingEvent event) {
        Korisnik korisnik = null;
        if(event.getName().compareTo("korisnik") == 0){
            korisnik = (Korisnik) event.getValue();
            System.out.println("Korisnik: " + korisnik.getIme() + " je prijavljen. ");

            
            // TODO dodati korisnika u popis korisnika
            // TODO idejs koristiti npr. Klasu vektor i slč. i zapisati u atribut konteksta. Pažnja! Višekorisnički rad.
            
        }
    }

    public void attributeRemoved(HttpSessionBindingEvent event) {
        Korisnik korisnik = null;
        if(event.getName().compareTo("korisnik") == 0){
            korisnik = (Korisnik) event.getValue();
            System.out.println("Korisnik: " + korisnik.getIme() + " je odjavljen. ");
            // TODO izbrisati korisnika iz popisa korisnika
        }
    }

    public void attributeReplaced(HttpSessionBindingEvent event) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
