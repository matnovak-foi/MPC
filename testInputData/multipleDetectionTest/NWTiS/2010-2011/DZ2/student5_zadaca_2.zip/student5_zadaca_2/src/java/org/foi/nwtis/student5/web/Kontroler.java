/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student5.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.foi.nwtis.student5.konfiguracije.bp.BP_Konfiguracija;
import org.foi.nwtis.student5.web.kontrole.Korisnik;

/**
 *
 * @author nwtis_3
 */
public class Kontroler extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            String akcija = request.getServletPath();
            RequestDispatcher rd = null;

            if (akcija.compareTo("/Kontroler") == 0) {
                rd = request.getRequestDispatcher("/jsp/index.jsp");
            } else if (akcija.compareTo("/PrijavaKorisnika") == 0) {
                rd = request.getRequestDispatcher("/jsp/login.jsp");
            } else if (akcija.compareTo("/ProvjeraKorisnika") == 0) {
                boolean login = false;
                if (request.getParameter("korisnik") != null
                        && request.getParameter("lozinka") != null) {
                    String korisnik = request.getParameter("korisnik");
                    String lozinka = request.getParameter("lozinka");

                    //Provjeravanje s bazom
                    BP_Konfiguracija bpKonfig = (BP_Konfiguracija) getServletContext().getAttribute("BP_konfiguracija");

                    String url = bpKonfig.getGlavniServerDB() + bpKonfig.getBazaPodatakaKorisnika();
                    Connection con;
                    Statement stmt;
                    String query = "select prezime, ime, korisnik, lozinka from POLAZNICI";

                    try {
                        Class.forName(bpKonfig.getUpravljackiProgram());

                    } catch (java.lang.ClassNotFoundException e) {
                        System.err.print("ClassNotFoundException: ");
                        System.err.println(e.getMessage());
                    }

                    try {
                        con = DriverManager.getConnection(url, bpKonfig.getNazivKorisnika(), bpKonfig.getLozinkaKorisnika());
                        stmt = con.createStatement();
                        ResultSet rs = stmt.executeQuery(query);

                        while (rs.next()) {
                            if (rs.getString("korisnik") == korisnik && rs.getString("lozinka") == lozinka) {
                            System.out.println("Korisnik " + korisnik + " prijavljen");
                            HttpSession sesija = request.getSession(true);
                            Korisnik kor = new Korisnik(korisnik, rs.getString("prezime"), rs.getString("ime"), sesija.getId(), 0);
                            sesija.setAttribute("korisnik", kor);
                            login = true;
                            }
                        }

                        stmt.close();
                        con.close();

                    } catch (SQLException ex) {
                        System.err.println("SQLException: " + ex.getMessage());
                    }


                    //Ostavljeno zbog nemogucnosti spajanja na bazu
                    if (korisnik.compareTo("pero") == 0 && lozinka.compareTo("12345") == 0) {
                        System.out.println("Korisnik " + korisnik + " prijavljen");
                        HttpSession sesija = request.getSession(true);
                        Korisnik kor = new Korisnik(korisnik, "Kos", "Pero", sesija.getId(), 0);
                        sesija.setAttribute("korisnik", kor);
                        login = true;
                    }
                }
                if (login) {
                    rd = request.getRequestDispatcher("/IspisKorisnika_2");
                } else {
                    rd = request.getRequestDispatcher("/PrijavaKorisnika");

                }
            } else if (akcija.compareTo("/IspisKorisnika_2") == 0) {
                rd = request.getRequestDispatcher("/privatno/IspisKorisnika_2.jsp");
            }
            rd.forward(request, response);
        } finally {
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
