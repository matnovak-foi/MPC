/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.foi.nwtis.student5.slusaci;

import java.io.File;
import java.util.Vector;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import org.foi.nwtis.student5.konfiguracije.bp.BP_Konfiguracija;
import org.foi.nwtis.student5.web.kontrole.Korisnik;

/**
 * Web application lifecycle listener.
 * @author student5
 */
public class SlusacAplikacije implements ServletContextListener {

    public void contextInitialized(ServletContextEvent sce) {
        String nazivDatoteke = sce.getServletContext().getRealPath("WEB-INF") + File.separator
                    + sce.getServletContext().getInitParameter("konfiguracija");
            File datoteka = new File(nazivDatoteke);
        try {
            BP_Konfiguracija bpKonfig = new BP_Konfiguracija(datoteka.getAbsolutePath());

            sce.getServletContext().setAttribute("BP_Konfiguracija", bpKonfig);
            Vector korisnici = new Vector();
            sce.getServletContext().setAttribute("Korisnici", korisnici);

            System.out.println("Kontekst " + sce.getServletContext().getContextPath() + " je inicijaliziran");
            String serverDatabase = ((BP_Konfiguracija)sce.getServletContext().getAttribute("BP_Konfiguracija")).getGlavniServerDB();
            System.out.println("Server database: " + serverDatabase);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void contextDestroyed(ServletContextEvent sce) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
