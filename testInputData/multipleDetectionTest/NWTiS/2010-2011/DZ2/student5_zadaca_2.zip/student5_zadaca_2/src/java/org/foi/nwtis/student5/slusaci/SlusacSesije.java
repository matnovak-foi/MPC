/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.foi.nwtis.student5.slusaci;

import java.util.Vector;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpSessionAttributeListener;
import javax.servlet.http.HttpSessionBindingEvent;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;
import org.foi.nwtis.student5.web.kontrole.Korisnik;

/**
 * Web application lifecycle listener.
 * @author student5
 */
public class SlusacSesije implements HttpSessionListener, HttpSessionAttributeListener {

    public void sessionCreated(HttpSessionEvent se) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void sessionDestroyed(HttpSessionEvent se) {
        //TODO obrisati korisnika u popis korisnika ako je aktivan. Ideja potraži korisnika koji ima broj sesije
    }

    public void attributeAdded(HttpSessionBindingEvent event) {
        Korisnik korisnik = null;
        if (event.getName().compareTo("korisnik") == 0) {
            korisnik = (Korisnik)event.getValue();
            System.out.println("Korisnik: " + korisnik.getIme() + " je prijavljen.");
            //TODO dodati korisnika u popis korisnika
            //Vector context = (Vector)getServletContext().getAttribute("Korisnici");

            //TODO koristiti npr. klasu Vector i zapisati u atribut konteksta. Pažnja! višekorisnički rad!?
        }
    }

    public void attributeRemoved(HttpSessionBindingEvent event) {
        Korisnik korisnik = null;
        if (event.getName().compareTo("korisnik") == 0) {
            korisnik = (Korisnik)event.getValue();
            System.out.println("Korisnik: " + korisnik.getIme() + " je prijavljen.");
            //TODO obrisati korisnika u popis korisnika
        }
    }

    public void attributeReplaced(HttpSessionBindingEvent event) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
