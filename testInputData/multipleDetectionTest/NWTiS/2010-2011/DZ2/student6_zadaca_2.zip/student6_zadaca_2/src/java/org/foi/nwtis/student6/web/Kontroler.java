/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student6.web;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.foi.nwtis.student6.konfiguracije.bp.BP_Konfiguracija;
import org.foi.nwtis.student6.web.kontrole.Korisnik;

/**
 *
 * @author student6
 */
public class Kontroler extends HttpServlet {

    /** 
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            String akcija = request.getServletPath();
            System.out.println("Akcija: " + akcija);
            RequestDispatcher rd = request.getRequestDispatcher("/index.jsp");

            if (akcija.compareTo("/ProvjeraKorisnika") == 0) {

                boolean loginOK = false;
                if (request.getParameter("korisnik") != null && request.getParameter("lozinka") != null) {
                    String korisnik = request.getParameter("korisnik");
                    String lozinka = request.getParameter("lozinka");
                    String rez = ispravnaPrijava(korisnik, lozinka);
                    System.out.println("ispravna prijava: " + rez);
                    if (!rez.equals("")) {
                        HttpSession sesija = request.getSession(true);
                        String[] korisnikBaza = rez.split("#");
                        Korisnik kor = new Korisnik(korisnikBaza[0], korisnikBaza[1], korisnikBaza[2], sesija.getId(), Integer.parseInt(korisnikBaza[3]));
                        sesija.setAttribute("korisnik", kor);
                        loginOK = true;
                        System.out.println("prijava OK: " + korisnikBaza[0]);
                    }

                }
                if (loginOK) {
                    rd = request.getRequestDispatcher("/IspisKorisnika_2");
                    //rd.forward(request, response);
                } else {
                    rd = request.getRequestDispatcher("/PrijavaKorisnika");
                    //rd.forward(request, response);
                }
            } else if (akcija.compareTo("/IspisKorisnika_2") == 0) {
                rd = request.getRequestDispatcher("/privatno/ispisKorisnika_2.jsp");
                //rd.forward(request, response);
            } else if (akcija.compareTo("/PrijavaKorisnika") == 0) {
                rd = request.getRequestDispatcher("/jsp/login.jsp");
            }
            rd.forward(request, response);
        } finally {
            out.close();
        }
    }

    private String ispravnaPrijava(String kor, String loz) {
        String nazivDatoteke = this.getServletContext().getRealPath("WEB-INF")
                + File.separator + this.getServletContext().getInitParameter("konfiguracija");

        File datoteka = new File(nazivDatoteke);

        BP_Konfiguracija bp = new BP_Konfiguracija(nazivDatoteke);
        Connection con;
        Statement stmt;
        String query = "";
        
        try {
            Class.forName(bp.getUpravljackiProgram());
        } catch (Exception ex) {
            //out.println(ex.toString());
        }

        try {
            System.out.println(bp.getPosluziteljBazePodataka());

            con = DriverManager.getConnection(bp.getPosluziteljBazePodataka() + bp.getKorisnikBazaPodataka(), bp.getKorisnikKorisnickoIme(), bp.getKorisnikLozinka());
            //con = DriverManager.getConnection(bp.getPosluziteljBazePodataka()+bp.getKorisnikBazaPodataka(), "root", "");

            stmt = con.createStatement();
            query = "SELECT * FROM polaznici WHERE kor_ime='" + kor + "' and lozinka = '" + loz + "';";
            ResultSet rs = stmt.executeQuery(query);


            if (rs.next()) {
                return rs.getString("kor_ime") + "#" + rs.getString("prezime") + "#" + rs.getString("ime") + "#" + rs.getString("vrsta");
            }

            stmt.close();
            con.close();

        } catch (SQLException ex) {
            System.err.println("SQLException: " + ex.getMessage());
        }
        return "";
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
