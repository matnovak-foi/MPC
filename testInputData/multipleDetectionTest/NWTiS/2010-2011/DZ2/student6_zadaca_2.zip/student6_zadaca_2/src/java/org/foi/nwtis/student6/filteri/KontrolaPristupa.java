/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student6.filteri;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 *
 * @author dkermek
 */
public class KontrolaPristupa implements Filter {

    private FilterConfig config = null;

    public void init(FilterConfig config) throws ServletException {
        this.config = config;
    }

    public void destroy() {
        config = null;
    }

    public void doFilter(ServletRequest request, ServletResponse response,
            FilterChain chain) throws IOException, ServletException {
        boolean nastaviRad = true;
        if (!(request instanceof HttpServletRequest)) {
            chain.doFilter(request, response);
        }
        System.out.println(((HttpServletRequest) request).getServletPath());
        if (((HttpServletRequest) request).getServletPath().compareTo("/jsp/login.jsp") != 0
                && ((HttpServletRequest) request).getServletPath().compareTo("/jsp/ispisKorisnika_2.jsp") != 0) {
            HttpSession sesija = ((HttpServletRequest) request).getSession(false);
            if (sesija == null) {
                nastaviRad = false;
            } else {
                if (sesija.getAttribute("korisnik") == null) {
                    nastaviRad = false;
                }
            }
        }
        if (!nastaviRad) {
            RequestDispatcher rd = config.getServletContext().getRequestDispatcher(
                    "/jsp/login.jsp");
            rd.forward(request, response);
        } else {
            chain.doFilter(request, response);
        }
    }
}
