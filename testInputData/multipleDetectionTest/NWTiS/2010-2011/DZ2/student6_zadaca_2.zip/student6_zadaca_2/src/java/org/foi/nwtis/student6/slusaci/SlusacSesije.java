/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student6.slusaci;

import java.util.Iterator;
import java.util.Vector;
import javax.servlet.http.HttpSessionAttributeListener;
import javax.servlet.http.HttpSessionBindingEvent;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;
import org.foi.nwtis.student6.web.kontrole.Korisnik;
import javax.servlet.http.HttpServlet;

/**
 * Web application lifecycle listener.
 * @author student6
 */
public class SlusacSesije extends HttpServlet implements HttpSessionListener, HttpSessionAttributeListener {

    public static Vector aktivniKorisniciVector = new Vector();

    public void sessionCreated(HttpSessionEvent se) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void sessionDestroyed(HttpSessionEvent se) {
        //TODO u slucaju isteka vremena maknuti korisnika - koristiti session_id iz attr korisnika
    }

    public void attributeAdded(HttpSessionBindingEvent event) {
        if (event.getName().compareTo("korisnik") == 0) {
            Korisnik korisnik = (Korisnik) event.getValue();
            System.out.println("Korisnik: " + korisnik.getIme() + " je prijavljena");
            aktivniKorisniciVector.add(korisnik);

            getServletContext().setAttribute("aktKor", aktivniKorisniciVector);
        }
    }

    public static Vector ispisAktivnihKorisnika() {
        //System.out.println("Ispis korisnika");

       /* for (int i=0;i<aktivniKorisniciVector.size();i++){
           System.out.println(((Korisnik)aktivniKorisniciVector.elementAt(i)).getIme());
        }*/

        return aktivniKorisniciVector;
       
    }

    public void attributeRemoved(HttpSessionBindingEvent event) {
        Korisnik korisnik = (Korisnik) event.getValue();
        aktivniKorisniciVector.removeElement(korisnik.getPrezime() + " " + korisnik.getPrezime());
    }

    public void attributeReplaced(HttpSessionBindingEvent event) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
