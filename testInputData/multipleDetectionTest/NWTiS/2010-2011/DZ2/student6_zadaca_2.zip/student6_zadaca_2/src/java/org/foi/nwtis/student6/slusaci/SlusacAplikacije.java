/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student6.slusaci;

import java.io.File;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import org.foi.nwtis.student6.konfiguracije.bp.BP_Konfiguracija;

/**
 * Web application lifecycle listener.
 * @author student6
 */
public class SlusacAplikacije implements ServletContextListener {

    public void contextInitialized(ServletContextEvent sce) {
        System.out.println("Kontekst je inicijaliziran " + sce.getServletContext().getContextPath());

        String nazivDatoteke = sce.getServletContext().getRealPath("WEB-INF")
                + File.separator + sce.getServletContext().getInitParameter("konfiguracija");

        File datoteka = new File(nazivDatoteke);

        BP_Konfiguracija bp = new BP_Konfiguracija(nazivDatoteke);
        sce.getServletContext().setAttribute("BP_Konfiguracija", bp);
        System.out.println("baza: " + ((BP_Konfiguracija)sce.getServletContext().getAttribute("BP_Konfiguracija")).getPosluziteljBazePodataka());

    }

    public void contextDestroyed(ServletContextEvent sce) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
