package org.foi.mpc.utility;

import org.foi.mpc.filesystem.TextFileUtility;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;

public class InMemoryTextFileUtility extends TextFileUtility {


    @Override
    public String readFileContentToString(File file) throws IOException {
        InMemoryFile imfile = (InMemoryFile) file;
        return  imfile.readContent();
    }
}