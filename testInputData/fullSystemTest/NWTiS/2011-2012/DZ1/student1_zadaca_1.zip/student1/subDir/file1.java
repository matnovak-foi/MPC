package org.foi.mpc.utility;

import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

public class InMemoryFile extends File {

    String content = null;
    InMemoryDir myDir;

    public InMemoryFile(String pathname) {
        super(pathname);
        this.myDir = null;
    }

    public void setMyDir(InMemoryDir dir){
        myDir = dir;
    }

    @Override
    public boolean delete() {
        myDir.deleteFile(this);
        return true;
    }

    public void appendContent(String content) {
        this.content += content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String readContent() {
        return content;
    }

    @Override
    public boolean exists() {
        return this.content != null;
    }
}