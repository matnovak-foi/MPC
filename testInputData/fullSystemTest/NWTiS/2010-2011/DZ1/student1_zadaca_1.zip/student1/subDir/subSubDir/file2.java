package org.foi.mpc.utility;

import org.foi.mpc.filesystem.TextFileUtility;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;

public class InMemoryTextFileUtility extends TextFileUtility {

    public InMemoryTextFileUtility(Charset charset) {
        super(charset);
    }

    @Override
    public void appendTextToFile(File file, String text) throws IOException {
        InMemoryFile imfile = (InMemoryFile) file;
        imfile.appendContent(text);
    }

    @Override
    public void createFileWithText(File file, String text) throws IOException {
        InMemoryFile imfile = (InMemoryFile) file;
        imfile.setContent(text);
    }

    @Override
    public File createFileWithText(File dir, String fileName, String text) throws IOException {
        InMemoryFile imFile = new InMemoryFile(fileName);
        createFileWithText(imFile,text);
        return imFile;
    }

    @Override
    public String readFileContentToString(File file) throws IOException {
        InMemoryFile imfile = (InMemoryFile) file;
        return  imfile.readContent();
    }
}