/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.foi.nwtis.student31.konfiguracije;

import java.util.Properties;

/**
 *
 * @author nwtis_3
 */
// ova klasa se ne može instancirati
public abstract class KonfiguracijaApstraktna implements Konfiguracija
{
    protected Properties postavke = new Properties();

    public String dajPostavku(String postavka) {
        return this.postavke.getProperty(postavka);
    }

    public boolean spremiPostavku(String postavka, String vrijednost)
    {
         if(this.postojiPostavka(postavka)){
            return false;
         }
         else{
            this.postavke.setProperty(postavka, vrijednost);
            return true;
         }
    }

    public boolean azurirajPostavku(String postavka, String vrijednost) {
         if(!this.postojiPostavka(postavka)){
            return false;
         }
         else{
            this.postavke.setProperty(postavka, vrijednost);
            return true;
         }
    }

    public boolean postojiPostavka(String postavka) {
        return this.postavke.containsKey(postavka);
    }

    public static Konfiguracija Konfiguracija(String naziv)
    {

        Konfiguracija konfig = null;

        if(naziv.endsWith(".xml")){
            konfig = new KonfiguracijaXML();
        }
        else{
            konfig = new KonfiguracijaTxt();
        }

        return konfig;
    }
}
