/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.foi.nwtis.student31.zadaca_1;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author nwtis_3
 */
public class Dnevnik {
    private String nazivDatoteke;

    private Dnevnik() {
    }

    public static Dnevnik getInstance() {
        return DnevnikHolder.INSTANCE;
    }

    private static class DnevnikHolder {
        private static final Dnevnik INSTANCE = new Dnevnik();
    }

    public String getNazivDatoteke() {
        return nazivDatoteke;
    }

    public void setNazivDatoteke(String nazivDatoteke) {
        this.nazivDatoteke = nazivDatoteke;
    }

    // zapisivanje podataka u datoteku dnevnika
    //
    public synchronized void upisi(String poruka)
    {
        try
        {

            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy_MM_dd");
            String dt = sdf.format(new java.util.Date());

            String myFile = nazivDatoteke + "." + dt + ".log";

            FileWriter outFile = new FileWriter(myFile,true);
            PrintWriter out = new PrintWriter(outFile);

            out.println(poruka);
            out.close();
            
        }
        catch (IOException ioe) {
            ioe.printStackTrace();
        }

    }

 }
