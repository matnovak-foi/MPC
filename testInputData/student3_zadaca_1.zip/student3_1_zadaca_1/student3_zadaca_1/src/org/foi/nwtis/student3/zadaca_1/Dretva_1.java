/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.foi.nwtis.student31.zadaca_1;


import java.net.*;
import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author nwtis_3
 */
public class Dretva_1 extends Thread{
    public int broj;
    private int interval;
    private String  izvor;
    private Dnevnik dnevnik;
    private int velicina;

    private long start;
    private long end;
    private long trajanje;

    public Dretva_1(int broj, int interval, String izvor, Dnevnik dnevnik) {
        super("nwtis => student31 => dretva_1 => broj: " + broj);
        this.broj = broj;
        this.interval = interval;
        this.izvor = izvor;
        this.dnevnik = dnevnik;

        System.out.println("Dretva " + broj + " inicijalizirana.");
    }

    

    @Override
    public void run()  {
       System.out.println(this.getName() + " pokrenuta");

       int iteracija=0;
       while(true)
       {
            try {

                start = System.currentTimeMillis();

                
                try {
                    // zapisivanje podataka u datoteku dnevnika
                    zapisiUDnevnik();
                } catch (IOException ex) {
                    Logger.getLogger(Dretva_1.class.getName()).log(Level.SEVERE, null, ex);
                }

                

                // izracunavanje novog intervala

                end = System.currentTimeMillis();
                trajanje = (interval * 1000) + (end - start);

                sleep(trajanje);


            } catch (InterruptedException ex) {
                System.out.println(this.getName() + " prekinuta!");
                //TODO: upisati u dnevnik da je dretva prekinuta
                break;
            }
       }
    }

    // sluzi za zapisivanje podataka u datoteku dnevnika
    //
    private void zapisiUDnevnik()throws IOException
    {
        int  zbroj=0;

        // formatiranje datuma
        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy.MM.dd hh.mm.ss");
        String dt = sdf.format(new java.util.Date()).toString();

        try
        {
             // spajanje na izvod
             URL u = new URL(izvor);

             InputStream in = u.openStream();
             in = new BufferedInputStream(in);
             Reader r = new InputStreamReader(in);

             // odredjivanje velicine datoteke (ivora), spremanje rezultata u varijablu 'zbroj'
             int c;
             while ((c = r.read()) != -1) {
                zbroj++;
             }

             // provjera je li došlo do promjene velicine datoteke, te ako je doslo
             // upisuje se odgovarajuca poruka u dnevnik
             if(velicina!=zbroj)
             {
                 dnevnik.upisi(broj + " " + dt + " PROMIJENJENA");

                 // postavljanje nove velicine datoteke u varijablu 'velicina'
                 velicina = zbroj;
             }
             else{
                 dnevnik.upisi(broj + " " + dt + " NIJE PROMIJENJENA");
                 System.out.println(broj + " " + dt + " NIJE PROMIJENJENA" + izvor + zbroj);
             }

        }
        catch (IOException ex) {
                System.out.println(ex.getMessage());

        }

    }


}
