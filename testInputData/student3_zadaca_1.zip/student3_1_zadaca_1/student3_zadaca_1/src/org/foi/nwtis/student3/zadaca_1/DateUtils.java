/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


package org.foi.nwtis.student31.zadaca_1;

/**
 *
 * @author student3
 */

import java.util.*;

// ova klasa sluzi kako bi dobili trenutno vrijeme u milisekundama (funkcija TrenutnoVrijemeUMS), odnosno
// dobili vrijeme u milisekundama prema spremljenom vremenu u konfiguracijskoj datoteci (funkcija VratiVrijemeUMS)

public class DateUtils
{
    
    public static long TrenutnoVrijemeUMS()
    {

        GregorianCalendar currentDate = new GregorianCalendar();
        return  currentDate.getTimeInMillis();

    }

    public static long VratiVrijemeUMS(String vrijemePocetka)
    {
        int sat = Integer.parseInt(vrijemePocetka.substring(0, 2));
        int min = Integer.parseInt(vrijemePocetka.substring(3, 5));
        int sec = Integer.parseInt(vrijemePocetka.substring(6, 8));

        GregorianCalendar currentDate = new GregorianCalendar();

        currentDate.set(Calendar.HOUR, sat);
        currentDate.set(Calendar.MINUTE,min);
        currentDate.set(Calendar.SECOND,sec);

        return currentDate.getTimeInMillis();
    }

}