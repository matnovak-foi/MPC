/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.foi.nwtis.student31.zadaca_1;

import java.io.File;
import java.util.Timer;
import java.util.TimerTask;

/**
 *
 * @author nwtis_3
 */
public class Dretva_3 extends TimerTask
{
    private String datotekaKraj;
    private Dretva_1[] dretve_1;
    private Dretva_2 dretva_2;
    private Timer timer;
    private Dnevnik dnevnik;


    public Dretva_3(String datotekaKraj, Dretva_1[] dretve_1, Dretva_2 dretva_2, Timer timer, Dnevnik dnevnik) {
        this.datotekaKraj = datotekaKraj;
        this.dretva_2 = dretva_2;
        this.dretve_1 = dretve_1;
        this.timer = timer;
        this.dnevnik = dnevnik;
    }


    @Override
    public void run() {
       System.out.println("Dretva 3 pokrenuta");
       File datoteka  = new File(datotekaKraj);

       if(!datoteka.exists())
       {
           System.out.println("Dretva 3 => Nema datoteke, ništa ne zaustavljam");
       }
       else // ako datoteka postoji - zaustavljanje svih dretvi
       {
           System.out.println("Dretva 3 => Pronađena datoteka, zaustavljam dretve");

           for(Dretva_1 d:dretve_1)
           {
               System.out.println("Dretva 3 => zaustavljam dretvu: " + d.getName());

               // zaustavljanje dretve
               d.interrupt();

               java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy.MM.dd hh.mm.ss");
               String dt = sdf.format(new java.util.Date()).toString();


               // upisivanje u dnevnik poruke kako je dretva zaustavljena
               dnevnik.upisi(d.broj + " " + dt + " ZAUSTAVLJENA");
           }

           System.out.println("Dretva 3 => zaustavljam dretvu: " + dretva_2.getName());
           dretva_2.interrupt();
           timer.cancel();
           
          }



    }


}
