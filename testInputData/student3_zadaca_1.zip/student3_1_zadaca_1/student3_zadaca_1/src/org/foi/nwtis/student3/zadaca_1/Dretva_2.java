/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.foi.nwtis.student31.zadaca_1;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author nwtis_3
 */
public class Dretva_2 extends Thread{
    private String vrijemePocetka;
    private Dnevnik dnevnik;

        private long start;
        private long end;
        private long trajanje;

    public Dretva_2(String vrijemePocetka, Dnevnik dnevnik) {
        super("nwtis => student31 => dretva_2");
        this.vrijemePocetka = vrijemePocetka;
        this.dnevnik = dnevnik;
    }

    // vraca true ako datoteka postoji, a false ako ne postoji
    public Boolean provjeraDatoteke()
    {
        Boolean vrati = false;

        try {
            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy_MM_dd");
            String dt = sdf.format(new java.util.Date());

            // formiranje naziva datoteke
            String nazivFajla = dnevnik.getNazivDatoteke() + "." + dt + ".log";

            File datoteka = new File(nazivFajla);


            // ako datoteka ne postoji, kreiraj datoteku i vrati true
            if(!datoteka.exists())
            {
                datoteka.createNewFile();
                vrati=true;
            }
        
        }
        catch (IOException ex) {
                Logger.getLogger(Dretva_2.class.getName()).log(Level.SEVERE, null, ex);
        }

        return vrati;
    }


    @Override
    public void run() {
       System.out.println(this.getName() + " pokrenuta");
       int interval = 24 * 60 * 60 * 1000; // 1 dan
       int iteracija=0;

       while(true)
       {
            try {
                System.out.println(this.getName() + " izvodi iteraciju:" + iteracija++);

                // DateUtils klasa sluzi kako bi dobili trenutno vrijeme u milisekundama (funkcija TrenutnoVrijemeUMS), odnosno
                // dobili vrijeme u milisekundama prema spremljenom vremenu u konfiguracijskoj datoteci (funkcija VratiVrijemeUMS)

                if(DateUtils.TrenutnoVrijemeUMS()>=DateUtils.VratiVrijemeUMS(vrijemePocetka))
                {
                    provjeraDatoteke();
                    sleep(interval);
                }                


            } catch (InterruptedException ex) {
                System.out.println(this.getName() + " prekinuta!");
                break;
            }
       }
    }




}
