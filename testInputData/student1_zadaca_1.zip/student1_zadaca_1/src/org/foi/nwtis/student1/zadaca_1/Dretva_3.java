/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student1.zadaca_1;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Klasa za dretvu koja služi za terminiranje svih dretvi programa
 * @author student1
 */
public class Dretva_3 extends TimerTask {
    private String datotekaKraj;
    private Dretva_1 dretve_1[];
    private Dretva_2 dretva_2;
    private Dnevnik dnevnik;
    private Timer timer;

    /**
     * Konstruktor za dretvu koja služi za terminiranje svih dretvi programa
     *
     * @param datotekaKraj naziv datoteke čije postojanje signalizira dretvi da treba terminirati sve dretve
     * @param dretve_1 polje dretvi za analizu sadržaja sa zadane web adrese
     * @param dretva_2 dretva za kreiranje dnevnika
     * @param dnevnik objekt dnevnika
     * @param timer okidač za izvršavanje ove dretve
     */
    public Dretva_3(String datotekaKraj, Dretva_1 dretve_1[], Dretva_2 dretva_2, Dnevnik dnevnik, Timer timer) {
        this.datotekaKraj = datotekaKraj;
        this.dretve_1 = dretve_1;
        this.dretva_2 = dretva_2;
        this.dnevnik = dnevnik;
        this.timer = timer;
    }

    /**
     * Izvršavanje dretve koja služi za terminiranje svih dretvi programa
     */
    @Override
    public void run() {
        System.out.println("Dretva_3 pokrenuta");

        //Provjera da li postoji datotekaKraj
        File datoteka = new File(datotekaKraj);
        if (!datoteka.exists()) {
            System.out.println("Ne postoji zadana datoteka, nista ne prekidam");
            return;
        } else {
            System.out.println("Postoji zadana datoteka, prekidam dretve");
            //Prekidanje svih 1. dretvi
            for(Dretva_1 d : dretve_1) {
                System.out.println("Prekidam " + d.getName());
                d.interrupt();
                try {
                    //TODO pisati u dnevnik
                    String vrijeme=getVrijeme();
                    this.dnevnik.upisDnevnik("Prekidam dretvu_1 sa rednim brojem:" + d.getName()+", vrijeme prekida: "+vrijeme);
                } catch (IOException ex) {
                    Logger.getLogger(Dretva_3.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            System.out.println("Prekidam Dretvu_2, vrijeme prekida: ");
            
            //prekidanje 2. dretve
            try {
                String vrijeme=getVrijeme();
                this.dnevnik.upisDnevnik("Prekidam dretvu_2, vrijeme prekida: "+vrijeme);
                dretva_2.interrupt();
            } catch (IOException ex) {
                Logger.getLogger(Dretva_3.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            //prekidanje 3. dretve
            try {
                String vrijeme=getVrijeme();
                this.dnevnik.upisDnevnik("Prekidam dretvu_3, vrijeme prekida: "+vrijeme);
                timer.cancel();
            } catch (IOException ex) {
                Logger.getLogger(Dretva_3.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
    }

    /**
     * Metoda koja vraća trenutno sistemsko vrijeme kao String
     * @return
     */
    private String getVrijeme(){
        SimpleDateFormat format_datuma=new SimpleDateFormat("hh:mm:ss");
        //Ova metoda postavlja vrijednost datuma na trenutni sistemski datum
        format_datuma.set2DigitYearStart(new Date());
        Calendar calendar=format_datuma.getCalendar();
        String vrijeme=format_datuma.format(calendar.getTime());
        return vrijeme;
    }

}