/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student1.zadaca_1;

import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Klasa Dretve za analizu sadržaja sa zadane web adrese
 * @author student1
 */
public class Dretva_1 extends Thread{
    private int brojDretve;
    private int interval;
    private String izvorPodataka;
    private Dnevnik dnevnik;
    private String staraDatoteka;

    /**
     * Konstruktor za dretve za analizu sadržaja sa zadane web adrese
     *
     * @param brojDretve redni broj dretve
     * @param interval interval u sekundama
     * @param izvorPodataka web adresa izvora podataka
     * @param dnevnik objekt dnevnika
     */
    public Dretva_1(int brojDretve, int interval, String izvorPodataka, Dnevnik dnevnik) {
        super("NWTiS => student1 =>"+brojDretve);
        this.brojDretve=brojDretve;
        this.interval=interval;
        this.izvorPodataka=izvorPodataka;
        this.dnevnik=dnevnik;

        this.staraDatoteka="";
    }

    /**
     * Izvršavanje dretve s intervalnim izvršavanjem
     */
    @Override
    public void run() {
        int brojCiklusa=0;
        System.out.println("Dretva: "+this.getName()+" se izvršava");
        
        while(true){
            System.out.println("Dretva: "+this.getName()+" izvršava ciklus: "+brojCiklusa++);
            
            SimpleDateFormat format1=new SimpleDateFormat("MM_dd_HH_mm_ss");
            format1.set2DigitYearStart(new Date());
            Calendar calendar1=format1.getCalendar();
            long startTime=calendar1.getTimeInMillis();

            try{
                try {
                    // TODO Utvrditi veličinu izvora podataka, provjeriti veličinu u odnosu na prethodni ciklus, zapisati u dnevnik
                    URL u = new URL(this.izvorPodataka);
                    try {
                        if (u.openConnection().getContentType() != null) {
                            InputStream in;
                            try {
                                in = u.openStream();
                                in = new BufferedInputStream(in);
                                Reader r = new InputStreamReader(in);

                                SimpleDateFormat format=new SimpleDateFormat("yyyy.MM.dd hh.mm.ss");
                                format.set2DigitYearStart(new Date());
                                Calendar calendar=format.getCalendar();
                                String datum=format.format(calendar.getTime());

                                //Zapisivanje URL-a u datoteku
                                int znak;
                                String ime_datoteke=this.brojDretve+"_"+datum+"_tmp.txt";
                                FileWriter datoteka = new FileWriter(ime_datoteke);
                                BufferedWriter zapis = new BufferedWriter(datoteka);

                                while ((znak = r.read()) != -1) {
                                    zapis.write(znak);
                                }
                                zapis.close();
                                //

                                //Uspoređuvanje spremljene datoteke za prije spremljenom datotekom
                                //ukolika ona postoji
                                File datoteka1=null;
                                File datoteka2=null;
                                if(this.staraDatoteka==""){
                                    this.dnevnik.upisDnevnik("Spremam datoteku");
                                }else{
                                    String naziv1 = this.staraDatoteka;
                                    datoteka1 = new File(naziv1);
                                    String naziv2 = ime_datoteke;
                                    datoteka2 = new File(naziv2);
                                    boolean b=isChanged(datoteka1,datoteka2);
                                    if(b==true){
                                        this.dnevnik.upisDnevnik("Dretva_1 "+this.brojDretve+","+datum+", Status: "+"Došlo je do promjene na URL= "+this.izvorPodataka);
                                    }else{
                                        this.dnevnik.upisDnevnik("Dretva_1 "+this.brojDretve+","+datum+", Status: "+"Nema promjene na URL= "+this.izvorPodataka);
                                    }
                                }

                                //Nakon uspoređivanja stara datoteka nam više netreba pa ju obrišemo
                                if(datoteka1!=null) {
                                    boolean del=datoteka1.delete();
                                }

                                //Prethodno spremljena datoteka postaje stara datoteka
                                this.staraDatoteka=ime_datoteke;

                            } catch (IOException ex) {
                                Logger.getLogger(Dretva_1.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }
                    } catch (IOException ex) {
                        Logger.getLogger(Dretva_1.class.getName()).log(Level.SEVERE, null, ex);
                    }

                } catch (MalformedURLException ex) {
                    Logger.getLogger(Dretva_1.class.getName()).log(Level.SEVERE, null, ex);
                }

                // TODO utvrdi vrijeme korekcije intervala
                SimpleDateFormat format2=new SimpleDateFormat("MM_dd_HH_mm_ss");
                format2.set2DigitYearStart(new Date());
                Calendar calendar2=format2.getCalendar();
                long endTime=calendar2.getTimeInMillis();

                long razlika=endTime-startTime;
                long sleep_in_millis=interval*1000-razlika;
                sleep(sleep_in_millis);

            }catch(InterruptedException ex){
                // TODO Ispiši da se dogodio prekid
                System.out.println("Dogodio se prekid u dretvi_1");
                break;
            }
        }
    }

    /**
     * Pokretanje dretve
     */
    @Override
    public synchronized void start() {
        super.start();
    }

    /**
     * Metoda za uspoređivanje dvije datoteke
     *
     * @param datoteka1 prva datoteka
     * @param datoteka2 druga datoteka
     * @return true ako su datoteke različite inače false
     * @throws IOException
     */
    private boolean isChanged(File datoteka1, File datoteka2) throws IOException {
        boolean promjena = false;
        FileReader dat1 = null;
        FileReader dat2 = null;

        int c1 = 0, c2 = 0;
        try {
            dat1 = new FileReader(datoteka1);
            dat2 = new FileReader(datoteka2);
            try {
                while (c1 != -1 && c2 != -1) {
                    c1 = dat1.read();
                    c2 = dat2.read();

                    //System.out.println("usporedjujem: "+(char)c1+" i "+(char)c2);
                    if (c1 == c2) {
                        promjena = false;
                    } else {
                        promjena = true;
                        break;
                    }
                }
            } catch (IOException ex) {
                Logger.getLogger(Dretva_1.class.getName()).log(Level.SEVERE, null, ex);
                System.out.println("Dogodila se greška prilikom uspoređivanja u dretvi_1 sa rednim brojem: "+this.brojDretve);
            }

        } catch (FileNotFoundException ex) {
            Logger.getLogger(Dretva_1.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Dogodila se greška prilikom uspoređivanja u dretvi_1 sa rednim brojem: "+this.brojDretve);
        }
        if(dat1!=null) {dat1.close();}
        if(dat2!=null) {dat2.close();}
        return promjena;
  }

}
