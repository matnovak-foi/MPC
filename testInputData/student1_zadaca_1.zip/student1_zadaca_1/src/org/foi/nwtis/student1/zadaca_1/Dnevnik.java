/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student1.zadaca_1;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;

/**
 *
 * @author nwtis_1
 */
public class Dnevnik {
    private String nazivDatoteke;

    /**
     * Metoda koja vraća trenutno zadani naziv datoteke dnevnika
     * @return
     */
    public String getNazivDatoteke() {
        return nazivDatoteke;
    }

    /**
     * Metoda koja postavlja naziv datoteke dnevnika
     *
     * @param nazivDatoteke novi naziv datoteke dnevnika
     */
    public void setNazivDatoteke(String nazivDatoteke) {
        this.nazivDatoteke = nazivDatoteke;
    }
    private Dnevnik(){

    }

    public static Dnevnik getInstance(){
        return DnevnikHolder.Instance;
    }
    
    public static class DnevnikHolder{
        private static final Dnevnik Instance=new Dnevnik();
    }

    /**
     * Metoda koja upisuje zadani tekst u datoteku dnevnika
     *
     * @param tekst tekst koji želimo upisati
     * @throws IOException
     */
    public synchronized void upisDnevnik(String tekst) throws IOException{
        // TODO dovršiti upis u dnevnik
        FileWriter log = new FileWriter(this.nazivDatoteke, true);
        BufferedWriter buff_unos = new BufferedWriter(log);
        Date vrijeme = new Date();

        buff_unos.write(tekst);
        buff_unos.newLine();
        buff_unos.close();
    }
}
