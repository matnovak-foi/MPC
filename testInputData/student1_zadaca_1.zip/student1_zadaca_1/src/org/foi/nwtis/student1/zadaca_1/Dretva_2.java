/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.foi.nwtis.student1.zadaca_1;
import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Klasa Dretve za kreiranje novog dnevnika
 * @author student1
 */
public class Dretva_2 extends Thread{
    private String vrijemePocetka;
    private Dnevnik dnevnik;
    private String dnevnikBaza;

    /**
     * Konstruktor za dretvu za kreiranje novog dnevnika
     *
     * @param vrijemePocetka vrijeme u koje se dretva pokreće
     * @param dnevnik objekt dnevnika
     * @param dnevnikBaza zadani prefiks za naziv datoteke dnevnika
     */
    public Dretva_2(String vrijemePocetka, Dnevnik dnevnik, String dnevnikBaza) {
        super("NWTiS => student1 => Dnevnik mjenjač");
        this.vrijemePocetka=vrijemePocetka;
        this.dnevnik=dnevnik;
        this.dnevnikBaza=dnevnikBaza;
    }

    /**
     * Izvršavanje dretve za kreiranje novog dnevnika
     */
    @Override
    public void run() {
        int brojCiklusa=0;
        System.out.println("Dretva: "+this.getName()+" se izvršava");
        while(true){
            System.out.println("Dretva: "+this.getName()+" izvršava ciklus: "+brojCiklusa++);

            // TODO utvrdi trenutno vrijeme i razliku do vremena početka, pozovi sleep(razlika)
            Calendar calendar1 = Calendar.getInstance();
            //Postavljanje kalendara na sistemsko vrijeme (u milisekundama)
            calendar1.setTimeInMillis(System.currentTimeMillis());
            Date startTime = calendar1.getTime();

            SimpleDateFormat format=new SimpleDateFormat("hh:mm:ss");
            //Postavljanje vremena u calendaru1 na vrijemePocetka
            try {
                format.parse(this.vrijemePocetka);
            } catch (ParseException ex) {
                Logger.getLogger(Dretva_2.class.getName()).log(Level.SEVERE, null, ex);
            }
            //Postavljanje datuma u calendaru2 na isto ono koje je postavljeno u calendaru1
            Calendar calendar2=format.getCalendar();
            calendar2.set(Calendar.YEAR, calendar1.get(Calendar.YEAR));
            calendar2.set(Calendar.MONTH, calendar1.get(Calendar.MONTH));
            calendar2.set(Calendar.DAY_OF_MONTH, calendar1.get(Calendar.DAY_OF_MONTH));

            //Ukoliko je vrijemePocetka prije trenutnog sistemskog vremena potrebno je vrijeme
            //postavljeno u kalendar2 prebaciti u sljedeći dan kako bi se razlika između dva kalendara
            //ispravno izračunala
            if(calendar2.compareTo(calendar1)<0){
                calendar2.roll(Calendar.DAY_OF_MONTH,1);
            }
            Date endTime = calendar2.getTime();

            //Razlika trenutnog vremena i vremena početka (u milisekundama)
            long razlika = endTime.getTime() - startTime.getTime();
            try {
                sleep(razlika);
            } catch (InterruptedException ex) {
                Logger.getLogger(Dretva_2.class.getName()).log(Level.SEVERE, null, ex);
                System.out.println("Dogodio se prekid u dretvi_2");
                break;
            }

            // TODO promijeniti naziv dnevika i utvrditi korekciju kolko je prošlo vremena tako da svaki dan počne u isto vrijeme
            SimpleDateFormat format_datuma=new SimpleDateFormat("yyyy_MM_dd");
            //Ova metoda postavlja vrijednost datuma na trenutni sistemski datum
            format_datuma.set2DigitYearStart(new Date());
            Calendar calendar=format_datuma.getCalendar();
            String datum=format_datuma.format(calendar.getTime());

            //Novi naziv dnevnika
            String naziv =this.dnevnikBaza+"."+datum+".log";
            this.dnevnik.setNazivDatoteke(naziv);

            //Kreiranje datoteke za novi dnevnik
            File datoteka = new File(naziv);
            try {
                boolean b = datoteka.createNewFile();
            } catch (IOException ex) {
                Logger.getLogger(Dretva_2.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    /**
     * Pokretanje dretve
     */
    @Override
    public synchronized void start() {
        super.start();
    }
}
