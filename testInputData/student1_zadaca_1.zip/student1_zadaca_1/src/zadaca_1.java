
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Timer;

import org.foi.nwtis.student1.konfiguracije.Konfiguracija;
import org.foi.nwtis.student1.konfiguracije.KonfiguracijaApstraktna;
import org.foi.nwtis.student1.zadaca_1.Dnevnik;
import org.foi.nwtis.student1.zadaca_1.Dretva_1;
import org.foi.nwtis.student1.zadaca_1.Dretva_2;
import org.foi.nwtis.student1.zadaca_1.Dretva_3;


/**
 * Višedretveni analizator sadržaja:
 *
 * Primjer korištenja dretvi s intervalnim izvršavanjem i s
 * fiksnim vremenskim izvršavanjem
 * @author student1
 */
public class zadaca_1 {

/**
 * Glavna metoda programa
 *
 * @param args datoteka konfiguracijskih postavki u txt ili xml formatu
 */
    public static void main(String[] args) {
        if(args.length != 1) {
            System.out.println("Broj argumenata nije 1.");
            return;
        }

        String naziv = args[0];
        File datoteka = new File(naziv);
        
        if(!datoteka.exists()) {
            System.out.println("Ne postoji datoteka konfiguracije");
        }

        Konfiguracija konfig=KonfiguracijaApstraktna.Konfiguracija(naziv);
        konfig.ucitajKonfiguraciju(naziv);

        int brojDretvi=Integer.parseInt(konfig.dajPostavku("brojDretvi"));
        int interval_1=Integer.parseInt(konfig.dajPostavku("interval_1"));
        int interval_3=Integer.parseInt(konfig.dajPostavku("interval_3"));
        String dnevnikBaza=konfig.dajPostavku("dnevnik");
        String vrijemePocetka=konfig.dajPostavku("vrijemePocetka");
        String datotekaKraj=konfig.dajPostavku("datotekaKraj");

        Dnevnik dnevnik=Dnevnik.getInstance();

        // TODO naziv dnevnika treba biti u formatu dnevnik.yyyy_mm_dd.log
        SimpleDateFormat format_datuma=new SimpleDateFormat("yyyy_MM_dd");
        //Ova metoda postavlja vrijednost datuma na trenutni sistemski datum
        format_datuma.set2DigitYearStart(new Date());
        Calendar calendar=format_datuma.getCalendar();
        String datum=format_datuma.format(calendar.getTime());

        //Novi naziv dnevnika
        String novi_naziv =dnevnikBaza+"."+datum+".log";
        dnevnik.setNazivDatoteke(novi_naziv);


        Dretva_1 dretve_1[]=new Dretva_1[brojDretvi];
        String izvorPodataka=null;
        for(int i=0; i<brojDretvi; i++){
            izvorPodataka=konfig.dajPostavku("URL_"+(i+1));
            dretve_1[i]=new Dretva_1(i,interval_1, izvorPodataka, dnevnik);
            dretve_1[i].start();
        }

        Dretva_2 dretva_2=new Dretva_2(vrijemePocetka,dnevnik, dnevnikBaza);
        dretva_2.start();

        Timer timer=new Timer();
        Dretva_3 dretva_3=new Dretva_3(datotekaKraj,dretve_1,dretva_2, dnevnik, timer);
        timer.scheduleAtFixedRate(dretva_3, new Date(), interval_3*1000);
    }

}
